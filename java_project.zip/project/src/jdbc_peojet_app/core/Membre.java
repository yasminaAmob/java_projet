package jdbc_peojet_app.core;
import java.time.LocalDate;
import java.time.Period;
//import java.util.*;
/**
 * la classe Membre  contient les setters et getters pour la gestion des donn�es des membres , aussi qu'un constructeur et deux methodes; toString et toArray 
 * @author Ait m'hanf oubrahim yasmina
 * @author Aji Soukaina
 *
 */
public class Membre {
	
	private int id;
	private String nom;
	private String prenom;
	private String address;
	private int tele;
	private String mdp;
	private String date_naiss;
	private String nationalite;
	private String type_membre;
	private String filiere;
	private String genre;
	private String email;
	
	/**
	 * constructeur de la classe membre
	 * @param nom nom du membre
	 * @param prenom prenom  du membre 
	 * @param date_naiss date de naissance du membre
	 * @param address adresse du membre
	 * @param tele numero de telephone
	 * @param email email du membre 
	 * @param genre genre du membre
	 * @param filiere la filiere du membre
	 * @param type_membre type de membre
	 * @param nationalite nationalite du membre
	 * @param mdp mot de passe 
	 */
	
	public Membre( String nom, String prenom,String date_naiss, String address,int tele,String email, String genre, String filiere, String type_membre ,
			String nationalite, String mdp) {
		super();
		
		this.nom = nom;
		this.prenom = prenom;
		this.date_naiss = date_naiss;
		this.address = address;
		this.tele = tele;
		this.email = email;
		this.genre = genre;
		this.filiere = filiere;
		this.type_membre = type_membre;
		this.nationalite = nationalite;
		this.mdp = mdp;}
	
	
	//getters & setters
	/**
	 * recuperation de l'id du memebre
	 * @return id
	 */
	public int getId() {
		return id;
	}
	/**
	 * modifier l'id
	 * @param id id du membre
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * recuperation du mon du membre
	 * @return nom 
	 */
	public String getNom() {
		return nom;
	}
	/**
	 * modifier le nom du membre
	 * @param nom nom du membre
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}
	/**
	 * recuperation du prenom du membre
	 * @return prenom
	 */
	public String getPrenom() {
		return prenom;
	}
	/**
	 * modifier le prenom du mombre
	 * @param prenom prenom du mombre
	 */
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	/**
	 * recuperation de l'adresse du membre
	 * @return address
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * modier l'adresse du membre
	 * @param address adresse du membre
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	/**
	 * recuperation de numero de telephone du membre
	 * @return telephone  numero de telephone du membre
	 */
	public int getTele() {
		return tele;
	}
	/**
	 * modifier numero de telephone 
	 * @param tel numero de telephone 
	 */
	public void setTele(int tel) {
		this.tele = tel;
	}
	/**
	 * recuperation de la date de naissance du membre
	 * @return date 
	 */
	public String getDate_naiss() {
		return date_naiss;
	}
	/**
	 * modifier la date de naissance
	 * @param date_naiss date de naissance
	 */
	public void setDate_naiss(String date_naiss) {
		this.date_naiss = date_naiss;
	}
	/**
	 * recuperation de la nationalit� du membre 
	 * @return la nationalit�
	 */
	public String getNationalite() {
		return nationalite;
	}
	/**
	 * modifier la nationalit� 
	 * @param nationalite la nationalit� 
	 */
	public void setNationalite(String nationalite) {
		this.nationalite = nationalite;
	}
	/**
	 * recuperation du type du membre
	 * @return type
	 */
	public String getType_membre() {
		return type_membre;
	}
	/**
	 * modifier le type du membre
	 * @param type_membre type du membre
	 */
	public void setType_membre(String type_membre) {
		this.type_membre = type_membre;
	}
	/**
	 * recuperation de la filiere du membre
	 * @return la filiere 
	 */
	public String getFiliere() {
		return filiere;
	}
	/**
	 * modifier la filiere du membre 
	 * @param filiere filiere du membre 
	 */
	public void setFiliere(String filiere) {
		this.filiere = filiere;
	}
	/**
	 * recuperation du genre du membre 
	 * @return genre 
	 */
	public String getGenre() {
		return genre;
	}
	/**
	 * modifier le genre deu membre 
	 * @param genre  le genre 
	 */
	public void setGenre(String genre) {
		this.genre = genre;
	}
	/**
	 * recuperation de l'email du membre
	 * @return email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * modifier l'email du membre
	 * @param email email du membre
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * recuperation du mot de passe du membre
	 * @return mot de passe
	 */
	public String getMdp() {
		return mdp;
	}
	/**
	 * modifier le mot de passe du membre
	 * @param mdp mot de passe
	 */
	public void setMdp(String mdp) {
		this.mdp =mdp;
	}
	
	@Override
	
	public String toString() {
		return "Membre [id=" + id + ", nom=" + nom + ", prenom=" + prenom + ", address=" + address + ", tel=" + tele
				+ ", date_naiss=" + date_naiss + ", nationalite=" + nationalite + ", type_membre=" + type_membre
				+ ", filiere=" + filiere + ", genre=" + genre + "]";
	}
	/**
	 * recuperation du membre 
	 * @return la liste du membre
	 */
	 public String[] toArray(){
	        String[] array = {getNom(),getPrenom(),getDate_naiss(),getAddress(),String.valueOf(getTele()),getEmail(),getGenre(),getFiliere(),getType_membre(),getNationalite(),getMdp()};
	        return array;
	    }

	
}

