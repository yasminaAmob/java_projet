package jdbc_peojet_app.core;
/**
 * la classe reunion qui contient tous les getters et setters qui aident a la gestions des donn�es des reunions ,aussi qu'un constructeur et deux methodes , toString et toArray
 * @author Ait m'hend oubrahim Yasmina
 *@author Aji Soukaina
 */
public class Reunion {
	private int id_reunion;
	private String theme;
	private String heure_debut;
	private String heure_fin;
	private String type;
	private String date;
	private String lieu;
	/**
	 * constructeur de la classe reunion
	 * @param theme theme de rerunion
	 * @param heure_debut date du debut de la reunion
	 * @param heure_fin date de la fin de la reunion 
	 * @param type type de la reunion
	 * @param date date de la reunion
	 * @param lieu lieu de la reunion
	 */
	public  Reunion(String theme,String heure_debut,String heure_fin,String type,String date, String lieu) {
		super();
		this.theme=theme;
		this.heure_debut=heure_debut;
		this.heure_fin=heure_fin;
		this.type=type;
		this.date=date;
		this.lieu=lieu;

	}
	/**
	 * recuperation de l'id de la reunion
	 * @return id
	 */
		public int getId_reunion() {
		return id_reunion;
	}
		/**
		 * modifier le id de la reunion
		 * @param id_reunion id de la reunion
		 */
	public void setId_reunion(int id_reunion) {
		this.id_reunion = id_reunion;
	}
	/**
	 * recuperation du theme de la reunion
	 * @return theme
	 */
	public String getTheme() {
		return theme;
	}
	/**
	 * modifeir le theme de la reunion
	 * @param theme theme de la reunion
	 */
	public void setTheme(String theme) {
		this.theme = theme;
	}
	/**
	 * recuperation de l'heure de la reunion
	 * @return heure 
	 */
	public String getHeure_debut() {
		return heure_debut;
	}
	/**
	 * modofier l'heure de la reunion
	 * @param heure_debut heure de la reunion
	 */
	public void setHeure_debut(String heure_debut) {
		this.heure_debut = heure_debut;
	}
	/**
	 * recuperation de l'heure de la fin de la reunion
	 * @return heure fin
	 */
	public String getHeure_fin() {
		return heure_fin;
	}
	/**
	 * modifer l'heure de la fin 
	 * @param heure_fin heure de la fin
	 */
	public void setHeure_fin(String heure_fin) {
		this.heure_fin = heure_fin;
	}
	/**
	 * recuperation du type de la reunion
	 * @return type 
	 */
	public String getType() {
		return type;
	}
	/**
	 * modifier type de la reunion
	 * @param type type de la reunion
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * recuperation de la date de la reunion
	 * @return date
	 */
	public String getDate() {
		return date;
	}
	/**
	 *  modifier la date de la reunion
	 * @param date date de la reunion
	 */
	public void setDate(String date) {
		date = date;
	}
	/**
	 * recuperation du lieu de la reunion
	 * @return lieu
	 */
	public String getLieu() {
		return lieu;
	}
	/**
	 * modifier le lieu de la reunion
	 * @param lieu lieu de la reunion
	 */
	public void setLieu(String lieu) {
		this.lieu = lieu;
	}
	
	@Override
	public String toString() {
		return "Evenement [numRunion=" + id_reunion + ", theme=" + theme + 
				 ", heure_debut=" + heure_debut +"heure_fin"+heure_fin+", type="
				+ type +", date"+date+", lieu"+lieu+"]";
	}
	/**
	 * recuperation de la reunion en liste
	 * @return array
	 */
	public String[] toArray(){
        String[] array = {getTheme() ,getHeure_debut(),getHeure_fin(),getDate(),getLieu(),getType()};
        return array;
    }
	

}
