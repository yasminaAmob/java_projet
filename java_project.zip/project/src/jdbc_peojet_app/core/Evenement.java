package jdbc_peojet_app.core;

/**
 * cette classe contient tous les getters et setters pour la gestion des donn�es des �v�nements ,aussi qu'un constructeur et deux methodes; toString et toArray
 * @author Ait m'hand ou brahim yasmina
 * @author Aji soukain
 */
public class Evenement {
	private int numEvent;
	private String nomEvent;
	private String dateDebutfin;
	private String hd;
	private String hf;

	private String lieu;
	private String type;
	private double cout_initial;
	private double cout_final;
	
	/**
	 * c'est le constructeur de la classe evenement
	 * @param nomEvent nom 
	 * @param dateDebutfin date 
	 * @param hd  heure de debut
	 * @param hf  heure de la fin
	 * @param lieu le lieu
	 * @param type le type
	 * @param cout_initial cout initial
	 * @param cout_final  cout final
	 */
	public Evenement(String nomEvent,String dateDebutfin,String  hd ,String hf , String lieu,String type,double cout_initial,double cout_final) {
		 
		super();
		
		this.nomEvent=nomEvent;
		this.dateDebutfin=dateDebutfin;
		
		this.hd=hd;
		this.hf=hf;
		this.lieu=lieu;
		this.type=type;
		this.cout_initial=cout_initial;
		this.cout_final=cout_final;
		
		
	}
	//getter & setters
	/**
	 * recuperation du nom de l'�v�nement 
	 * @return nom de l'�n�nement
	 */
	public int getNumEvent() {
		return numEvent;
	}
	/**
	 * modification du nom de l'�v�nement
	 * @param numEvent nom de l'l'�v�nement
	 */
	public void setNumEvent(int numEvent) {
		this.numEvent = numEvent;}
	/**
	 * recuperation du co�t initial de l'�v�nemet
	 * @return  co�t initial
	 */
	public double getCoutInitial(){
		return cout_initial;
	}
	/**
	 * modifier le co�t initial
	 * @param cout_initial cout initial
	 */
	public void setCoutInitial(int cout_initial) {
		this.cout_initial=cout_initial;
	}
	/**
	 * recuperation du co�t final de l'�v�nement
	 * @return co�t final
	 */
	public double getCoutFinal(){
		return cout_initial;
	}
	/**
	 * modifier le co�t final
	 * @param cout_final co�t final
	 */
	public void setCoutFinal(int cout_final) {
		this.cout_final=cout_final;
	}
	/**
	 * recuperation du nom de l'�v�nement
	 * @return nom de l'�v�nement
	 */
	public String getNomEvent() {
		return nomEvent;
	}
	/**
	 * modifeir le nom de l'�v�nement
	 * @param nomEvent nom de l'�v�nement
	 */
	public void setNomEvent(String nomEvent) {
		this.nomEvent = nomEvent;
	}
	/**
	 * recuperation de la dure d'�v�nement 
	 * @return date 
	 */
	public String getDateDebutfin() {
		return dateDebutfin;
	}
	/**
	 * modifier la date
	 * @param dateDebutfin date l'�v�nement
	 */
	public void setDateDebutfin(String dateDebutfin) {
		this.dateDebutfin = dateDebutfin;
	}
	/**
	 * recuperation de l'heure d'�v�nement
	 * @return heure debut
	 */
	
	public String getHeureDebut() {
		return hd;
	}
	/**
	 * modifier l'heure d'�v�nement
	 * @param hd heure d'�v�nement
	 */
	public void setHeureDebut(String hd) {
		this.hd = hd;
	}
	/**
	 * recuperation de l'heure de la fin d'�v�nement
	 * @return heure de la fin
	 */
	public String getHeureFin() {
		return hf;
	}
	/**
	 * modifier l'heure fin d'�v�nement
	 * @param hf heure fin d'�v�nement
	 */
	public void setHeureFin(String hf) {
		this.hf = hf;
	}
	/**
	 * recuperation du lieu d'�v�nement
	 * @return le lieu 
	 */
	public String getLieu() {
		return lieu;
	}
	/**
	 * modifier le lieu de l'�v�nement
	 * @param lieu lieu de l'�v�nement
	 */
	public void setLieu(String lieu) {
		this.lieu = lieu;
	}
	/**
	 * recuperation du type d'�v�nement
	 * @return type 
	 */
	public String getType() {
		return type;
	}
	/**
	 * modifier type d'�v�nement
	 * @param type  type d'�v�nement
	 */
	public void setType(String type) {
		this.type = type;
	}
	
	@Override
	public String toString() {
		return "Evenement [numEvent=" + numEvent + ", nomEvent=" + nomEvent + ", dateDebutfin=" + dateDebutfin + 
				 ", heure_debut=" + hd +"heure_fin"+hf+ ", lieu=" + lieu + ", type="
				+ type +" cout_initial=" + cout_initial +", cout_final"+cout_final+"]";
	}
	/**
	 * 
	 * @return �v�nement en liste
	 */
	public String[] toArray(){
        String[] array = {getNomEvent() ,String.valueOf(getDateDebutfin()),String.valueOf(getHeureDebut()),String.valueOf(getHeureFin()),getType(),getLieu(),String.valueOf(getCoutInitial()),String.valueOf(getCoutFinal())};
        return array;
    }
	
	
}
