package test;

import static org.junit.jupiter.api.Assertions.*;

import junit.framework.TestCase;

import org.junit.jupiter.api.Test;

import jdbc_peojet_app.core.Membre;

class MembreTest extends TestCase{
	private Membre membre;
	
	public MembreTest(String name) {
	
	super(name);
	}
	
	protected void setUp() throws Exception {
		super.setUp();
		Membre membre = new Membre("nom","prenom","01-01_2001","address",01234567,"email","femme","2ite","noyau","marocaine","mdp");
		}
	protected void tearDown() throws Exception {
		super.tearDown();
		membre = null;
		}
	
	@Test
	public void testMembre() {
		assertNotNull("L'instance n'est pas cr��e", membre);
	}
	@Test
	public void testGetNom() {
		
		assertEquals("Le nom est incorrect", "nom", membre.getNom());
		}
	@Test
	public void testSetNom() {
		
		membre.setNom("nom1");
		assertEquals("Le nom est incorrect", "nom1", membre.getNom());
		
		}
	@Test
	public void testGetPrenom() {
		
		assertEquals("Le prenom est incorrect", "prenom", membre.getPrenom());
		
		}
	@Test
	public void testSetPrenom() {
		
		membre.setPrenom("prenom1");
		assertEquals("Le prenom est incorrect", "prenom1", membre.getPrenom());
		}
	@Test
	public void testGetPwd() {
		
		assertEquals("Le pwd est incorrect", "pwd", membre.getMdp());
		
		}
	@Test
	public void testSetPwd() {
		
		membre.setPrenom("pwd1");
		assertEquals("Le pwd est incorrect", "pwd1", membre.getMdp());
		}

	
}
