package jdbc_projet_app.ui;
import java.sql.*;
import java.util.Properties;
import java.awt.EventQueue;
import jdbc_projet_app.dao.MembreDao;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;

import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Font;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBox;
import java.awt.event.ItemListener;
import java.io.FileInputStream;
import java.awt.event.ItemEvent;
/**
 * cette classe qui permet l'authentification du membre � travers la Gui
 *@author Ait m'hand oubrahim yasmina 
 *@author Aji soukaina
 *
 */
public class Signup {

	private JFrame frmSignUp;
	private JTextField textField_login;
	private JTextField textField_password;

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Signup window = new Signup();
					window.frmSignUp.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Creation de l'application.
	 */
	public Signup() {
		initialize();
	}

	/**
	 * Initialisation du contenu de la frame.
	 */
	private void initialize() {
		frmSignUp = new JFrame();
		frmSignUp.setTitle("Sign up");
		frmSignUp.setBounds(100, 100, 347, 202);
		frmSignUp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmSignUp.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 342, 163);
		frmSignUp.getContentPane().add(panel);
		panel.setLayout(null);
		
		textField_login = new JTextField();
		textField_login.setBounds(104, 60, 148, 20);
		panel.add(textField_login);
		textField_login.setColumns(10);
		
		/*textField_password = new JTextField();
		textField_password.setBounds(125, 88, 148, 20);
		panel.add(textField_password);
		textField_password.setColumns(10);*/
		
		JPasswordField passwordField = new JPasswordField(20);
		passwordField.setBounds(104, 88, 148, 20);
		panel.add(passwordField);
		passwordField.setColumns(10);
		
		JCheckBox chckbxNewCheckBox = new JCheckBox("Show");
		chckbxNewCheckBox.setBackground(Color.WHITE);
		chckbxNewCheckBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if (chckbxNewCheckBox.isSelected())
					passwordField.setEchoChar((char)0);
				else 
				    passwordField.setEchoChar('*');
			}
		});
		chckbxNewCheckBox.setBounds(264, 87, 88, 23);
		panel.add(chckbxNewCheckBox);
		
		
		JButton btnNewButton = new JButton("Connexion");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String type=null;
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Properties props = new Properties();
			        props.load(new FileInputStream("env.properties"));

			        String user = props.getProperty("user");
			        String password = props.getProperty("password");
			        String dburl = props.getProperty("dburl");

			        // connect to database
			        Connection con = DriverManager.getConnection(dburl, user, password);
					Statement stat=con.createStatement();
					
					String sql="SELECT type FROM  membre  where email=? and pwd=?;";

					//ResultSet rs=stat.executeQuery(sql); 
					PreparedStatement pst = con.prepareStatement(sql);
					pst.setString(1,textField_login.getText());
					
					pst.setString(2,passwordField.getText());
					

					ResultSet rs=pst.executeQuery(); 
					
					if (rs.next()) { 
						 type=rs.getString(1);
					if (type.equals("Noyau")) {
						projectApp prj=new projectApp();
						prj.noyau();
						frmSignUp.dispose();
						
						}
					else if(type.equals("Adherent")) {
						AdherentEspace ad=new AdherentEspace();
						ad.AdherentEsp();
						frmSignUp.dispose();
						}
					}
						//JOptionPane.showMessageDialog(null, "login successfully");
					
					else 
						JOptionPane.showMessageDialog(null, "incorrecte login ou mdp");						
					
					con.close();
					
				}catch(Exception ex) {System.out.print(ex);};
			}
		});
		btnNewButton.setBounds(213, 129, 107, 23);
		panel.add(btnNewButton);
		
		
		
		JLabel lblUsernname = new JLabel("Login  :");
		lblUsernname.setBounds(10, 63, 74, 14);
		panel.add(lblUsernname);
		
		JLabel lblPassword = new JLabel("Mot de passe :");
		lblPassword.setBounds(10, 91, 83, 14);
		panel.add(lblPassword);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 51, 255));
		panel_1.setBounds(0, 0, 352, 39);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblClubX = new JLabel("App In Sciences");
		lblClubX.setForeground(Color.WHITE);
		lblClubX.setFont(new Font("Bookman Old Style", Font.BOLD, 13));
		lblClubX.setBounds(10, 0, 131, 26);
		panel_1.add(lblClubX);
		
		
	}
}
