
package jdbc_projet_app.ui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import java.awt.CardLayout;
import javax.swing.JTextField;
import javax.swing.JEditorPane;
import javax.swing.JScrollPane;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import com.jgoodies.forms.layout.FormSpecs;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.SystemColor;
import java.awt.Font;
import javax.swing.UIManager;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
/**
 * cette classe permet � un simple adherent d'acceder � l'application
 *  pour visualiser la liste des �v�nements et la liste des r�unione
 * @author Ait m'hand oubrahim yasmina 
 *@author Aji soukaina
 * 
 *
 */
public class AdherentEspace {

	private JFrame frmMenuPrincipal;
	private JPanel panel_1;
	private JLabel label;
	private JLabel lblUpOnScience;
	private JPanel panel_5;
	private JPanel panel_event;
	private JLabel label_4;
	private JLabel lblEvenement;
	private JPanel panel_reunion;
	private JLabel label_1;
	private JLabel lblReunion;
	private JLabel lblNewLabel;

	/**
	 * Launch the application.
	 */
	public static void AdherentEsp() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdherentEspace window = new AdherentEspace();
					window.frmMenuPrincipal.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Creation de l'application.
	 */
	public AdherentEspace() {
		initialize();
	}

	/**
	 * Initialiser le contenu de la frame.
	 */
	private void initialize() {
		frmMenuPrincipal = new JFrame();
		frmMenuPrincipal.setTitle("Menu principal");
		frmMenuPrincipal.setBounds(100, 100, 528, 494);
		frmMenuPrincipal.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		GroupLayout groupLayout = new GroupLayout(frmMenuPrincipal.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addComponent(panel, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 616, Short.MAX_VALUE)
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addComponent(panel, GroupLayout.DEFAULT_SIZE, 425, Short.MAX_VALUE)
		);
		panel.setLayout(null);
		
		panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 51, 255));
		panel_1.setForeground(new Color(0, 206, 209));
		panel_1.setBounds(0, 0, 526, 152);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		panel_5 = new JPanel();
		panel_5.setBounds(43, 30, 416, 79);
		panel_1.add(panel_5);
		panel_5.setBackground(new Color(0, 102, 255));
		panel_5.setLayout(null);
		
		label = new JLabel("");
		label.setBounds(22, 18, 50, 50);
		panel_5.add(label);
		label.setIcon(new ImageIcon(AdherentEspace.class.getResource("/project/images/icons8_physics_50px_2.png")));
		
		lblUpOnScience = new JLabel("App In Sciences");
		lblUpOnScience.setBounds(57, 0, 130, 29);
		panel_5.add(lblUpOnScience);
		lblUpOnScience.setBackground(new Color(255, 255, 255));
		lblUpOnScience.setForeground(new Color(255, 255, 255));
		lblUpOnScience.setFont(new Font("Arial", Font.BOLD, 14));
		
		panel_event = new JPanel();
		panel_event.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				setColor(panel_event);
			}
			public void mouseExited(MouseEvent e) {
				resetColor(panel_event);
			}

			private void setColor(JPanel panel) {
				// TODO Auto-generated method stub
				panel.setBackground(new Color(115, 163, 239));
			}
			private void resetColor(JPanel panel) {
				// TODO Auto-generated method stub
				panel.setBackground(new Color(240,240,240));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				ShowEventsAdherent event= new ShowEventsAdherent();
				event.EventA();
			}
		});
		panel_event.setLayout(null);
		panel_event.setBackground(SystemColor.menu);
		panel_event.setBounds(71, 232, 142, 114);
		panel.add(panel_event);
		
		label_4 = new JLabel("");
		label_4.setIcon(new ImageIcon(AdherentEspace.class.getResource("/project/images/icons8_calendar_filled_50px.png")));
		label_4.setBounds(46, 12, 50, 55);
		panel_event.add(label_4);
		
		lblEvenement = new JLabel("         Evenement");
		lblEvenement.setForeground(new Color(0, 51, 255));
		lblEvenement.setFont(new Font("Arial", Font.BOLD, 13));
		lblEvenement.setBounds(0, 78, 129, 14);
		panel_event.add(lblEvenement);
		
		panel_reunion = new JPanel();
		panel_reunion.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				setColor(panel_reunion);
			}
			public void mouseExited(MouseEvent e) {
				resetColor(panel_reunion);
			}

			private void setColor(JPanel panel) {
				// TODO Auto-generated method stub
				panel.setBackground(new Color(115, 163, 239));
			}
			private void resetColor(JPanel panel) {
				// TODO Auto-generated method stub
				panel.setBackground(new Color(240,240,240));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				ShowReunionAdherent  reun= new ShowReunionAdherent();
				reun.ReunionA();
			}
		});
		panel_reunion.setLayout(null);
		panel_reunion.setBackground(SystemColor.menu);
		panel_reunion.setBounds(295, 232, 142, 114);
		panel.add(panel_reunion);
		
		label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon(AdherentEspace.class.getResource("/project/images/icons8_meeting_room_filled_50px.png")));
		label_1.setBounds(45, 11, 54, 55);
		panel_reunion.add(label_1);
		
		lblReunion = new JLabel("         Reunion");
		lblReunion.setForeground(new Color(0, 51, 255));
		lblReunion.setFont(new Font("Arial", Font.BOLD, 13));
		lblReunion.setBounds(10, 77, 129, 14);
		panel_reunion.add(lblReunion);
		
		lblNewLabel = new JLabel("");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(0);
			}
		});
		lblNewLabel.setIcon(new ImageIcon(AdherentEspace.class.getResource("/project/images/icons8_exit_32px.png")));
		lblNewLabel.setBounds(466, 406, 36, 38);
		panel.add(lblNewLabel);
		frmMenuPrincipal.getContentPane().setLayout(groupLayout);
		
	}
}
