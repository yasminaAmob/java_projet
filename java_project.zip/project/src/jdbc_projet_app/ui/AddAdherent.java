package jdbc_projet_app.ui;
import  jdbc_peojet_app.core.Membre;
import jdbc_projet_app.dao.MembreDao;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.SpinnerNumberModel;
import jdbc_projet_app.dao.MembreDao;

import java.awt.Font;
/**
 * cette classe permet d'ajouter un membre dans la base donn�e � travers la GUI
 * @author Ait m'hand oubrahim yasmina 
 *@author Aji soukaina
 */
public class AddAdherent {

	private JFrame frmAjouterUnNouveau;
	private JTextField textField_nom;
	private JTextField textField_prenom;
	private JTextField txtJjmmaaaa;
	private JTextField textField_tel;
	private JTextField txtxxxxxxxx;
	private JTextField textField_mdp;
	private JTextField txtXxxxxgmailcom;

	/**
	 * Launch the application.
	 */
	
	public static void Add() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddAdherent window = new AddAdherent();
					window.frmAjouterUnNouveau.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Creation de l'application
	 */
	public AddAdherent() {
		initialize();
	}

	/**
	 * Initialiser le contenu de la frame
	 */
	
	private void initialize() {
		frmAjouterUnNouveau = new JFrame();
		frmAjouterUnNouveau.setTitle("Ajouter un nouveau membre");
		frmAjouterUnNouveau.setBounds(100, 100, 395, 638);
		frmAjouterUnNouveau.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmAjouterUnNouveau.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setToolTipText("");
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 379, 619);
		frmAjouterUnNouveau.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 51, 255));
		panel_1.setBounds(0, 0, 381, 52);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("App In Sciences ");
		lblNewLabel.setBounds(10, 11, 138, 18);
		lblNewLabel.setFont(new Font("Bookman Old Style", Font.BOLD, 14));
		lblNewLabel.setForeground(Color.WHITE);
		panel_1.add(lblNewLabel);
		
		textField_nom = new JTextField();
		textField_nom.setBounds(152, 90, 157, 20);
		panel.add(textField_nom);
		textField_nom.setColumns(10);
		
		textField_prenom = new JTextField();
		textField_prenom.setBounds(152, 129, 157, 20);
		panel.add(textField_prenom);
		textField_prenom.setColumns(10);
		
		txtJjmmaaaa = new JTextField();
		txtJjmmaaaa.setToolTipText("jj/mm/yyyy");
		txtJjmmaaaa.setBounds(152, 171, 157, 20);
		panel.add(txtJjmmaaaa);
		txtJjmmaaaa.setColumns(10);
		
		textField_tel = new JTextField();
		textField_tel.setToolTipText(" 06XXXXXXXX");
		textField_tel.setText(" ");
		textField_tel.setBounds(152, 248, 157, 20);
		panel.add(textField_tel);
		textField_tel.setColumns(10);
		
		JComboBox comboBox_filiere = new JComboBox();
		comboBox_filiere.setToolTipText("\r\n");
		comboBox_filiere.setModel(new DefaultComboBoxModel(new String[] {"Filiere ", "2ITE", "ISIC", "GI", "GEE", "Cycle Prepa"}));
		comboBox_filiere.setBounds(152, 366, 157, 20);
		panel.add(comboBox_filiere);
		
		JLabel lblNom = new JLabel("Nom :");
		lblNom.setBounds(33, 93, 46, 14);
		panel.add(lblNom);
		
		JLabel lblPrenom = new JLabel("Prenom :");
		lblPrenom.setBounds(33, 132, 61, 14);
		panel.add(lblPrenom);
		
		JLabel lblNaissance = new JLabel("Date de naissance :");
		lblNaissance.setBounds(33, 174, 119, 14);
		panel.add(lblNaissance);
		
		JLabel lblTalephone = new JLabel("Telephone :");
		lblTalephone.setBounds(33, 251, 75, 14);
		panel.add(lblTalephone);
		
		JLabel lblType = new JLabel("Filiere  :");
		lblType.setBounds(33, 369, 75, 14);
		panel.add(lblType);
		
		JLabel label = new JLabel("Type :");
		label.setBounds(33, 410, 75, 14);
		panel.add(label);
		
		JComboBox comboBox_type = new JComboBox();
		comboBox_type.setModel(new DefaultComboBoxModel(new String[] {"Type", "Noyau", "Adherent"}));
		comboBox_type.setToolTipText("\r\n");
		comboBox_type.setBounds(152, 407, 157, 20);
		panel.add(comboBox_type);
		
		
		
		JLabel lblAdresse = new JLabel("Adresse :");
		lblAdresse.setBounds(33, 212, 75, 14);
		panel.add(lblAdresse);
		
		txtxxxxxxxx = new JTextField();
		txtxxxxxxxx.setToolTipText("");
		txtxxxxxxxx.setColumns(10);
		txtxxxxxxxx.setBounds(152, 209, 157, 20);
		panel.add(txtxxxxxxxx);
		
		JLabel lblGenre = new JLabel("Genre :");
		lblGenre.setBounds(33, 332, 75, 14);
		panel.add(lblGenre);
		
		JComboBox comboBox_genre = new JComboBox();
		comboBox_genre.setModel(new DefaultComboBoxModel(new String[] {"Genre", "Femme", "Homme"}));
		comboBox_genre.setToolTipText("\r\n");
		comboBox_genre.setBounds(152, 329, 157, 20);
		panel.add(comboBox_genre);
		
		JLabel lblNationalit = new JLabel("Nationalit\u00E9 :");
		lblNationalit.setBounds(33, 451, 75, 14);
		panel.add(lblNationalit);
		
		JComboBox comboBox_nat = new JComboBox();
		comboBox_nat.setModel(new DefaultComboBoxModel(new String[] {"Nationalite ", "Maroc ", "Autre"}));
		comboBox_nat.setToolTipText("\r\n");
		comboBox_nat.setBounds(152, 448, 157, 20);
		panel.add(comboBox_nat);
		
		JLabel lblMotDePasse = new JLabel("Mot de passe  :");
		lblMotDePasse.setBounds(33, 487, 109, 14);
		panel.add(lblMotDePasse);
		
		textField_mdp = new JTextField();
		textField_mdp.setText(" ");
		textField_mdp.setColumns(10);
		textField_mdp.setBounds(152, 484, 157, 20);
		panel.add(textField_mdp);
		
		JLabel lblEmail = new JLabel("Email :");
		lblEmail.setBounds(33, 291, 75, 14);
		panel.add(lblEmail);
		
		txtXxxxxgmailcom = new JTextField();
		txtXxxxxgmailcom.setToolTipText("  xxxxx@gmail.com");
		txtXxxxxgmailcom.setColumns(10);
		txtXxxxxgmailcom.setBounds(152, 288, 157, 20);
		panel.add(txtXxxxxgmailcom);
		
		JButton ajoutermembre = new JButton("");
		ajoutermembre.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (!textField_nom.getText().isEmpty()&&
				!textField_prenom.getText().isEmpty()&&
				!txtJjmmaaaa.getText().isEmpty()&&
				!textField_tel.getText().isEmpty()&&
			!textField_mdp.getText().isEmpty()&&
				!String.valueOf(comboBox_filiere.getSelectedItem()).equals("Filiere")&&
				!String.valueOf(comboBox_type.getSelectedItem()).equals("Type")&&
				!txtxxxxxxxx.getText().isEmpty()&&
				!String.valueOf(comboBox_genre.getSelectedItem()).equals("Genre")&&
				!String.valueOf(comboBox_nat.getSelectedItem()).equals("Nationalite")&&
				!txtXxxxxgmailcom.getText().isEmpty()) {
					
					
					Membre membre = new Membre(textField_nom.getText(),textField_prenom.getText(), txtJjmmaaaa.getText(), txtxxxxxxxx.getText(),Integer.valueOf(textField_tel.getText().trim()),txtXxxxxgmailcom.getText(),String.valueOf(comboBox_genre.getSelectedItem()) ,String.valueOf(comboBox_filiere.getSelectedItem()),String.valueOf(comboBox_type.getSelectedItem()) ,
							String.valueOf(comboBox_nat.getSelectedItem()), textField_mdp.getText());
					
					 try {
						 String expression = "[A-Za-z]+@+[A-Za-z]+\\.+[A-Za-z]{2,4}+$";
							Pattern p = Pattern.compile(expression);
							Matcher m = p.matcher(txtXxxxxgmailcom.getText());
							if(!m.matches())
							{
							JOptionPane.showMessageDialog(null, "Email non valide");
							}
							else {
			                MembreDao.addMembre(membre);
			                crud.table.repaint();
			                
		                     
			                JOptionPane.showMessageDialog(null, "Added succesfully!");

			                frmAjouterUnNouveau.dispose(); 
			                
			               
							}
			                
			                
			                
			            } catch (Exception ex) {
			                ex.printStackTrace();
			            }	
			}
					else
			            JOptionPane.showMessageDialog(null, "Vous devez remplir tous les champs !");

			}
		});
		ajoutermembre.setIcon(new ImageIcon(AddAdherent.class.getResource("/project/images/icons8_add_user_male_30px_3.png")));
		ajoutermembre.setBounds(194, 531, 83, 52);
		panel.add(ajoutermembre);
		
	}
}
