package jdbc_projet_app.ui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JTextField;

import jdbc_peojet_app.core.Evenement;
import jdbc_projet_app.dao.EvenementDao;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
/**
 * cette classe permet de modifier un �v�nement � travers la Gui
 *@author Ait m'hand oubrahim yasmina 
 *@author Aji soukaina
 *
 */
public class ModifierEvent {

	private JFrame frmAjouterUnEvenement;
	private JTextField textField_hf;
	private JTextField txtDebutFin;
	private JTextField textField_nom;
	private JTextField textField_endroit;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_hd;

	/**
	 * Launch the application.
	 */
	public static void Event() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ModifierEvent window = new ModifierEvent();
					window.frmAjouterUnEvenement.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Creation de l'application.
	 */
	public ModifierEvent() {
		initialize();
	}

	/**
	 * Initialiser le contenu de la frame.
	 */
	private void initialize() {
		frmAjouterUnEvenement = new JFrame();
		frmAjouterUnEvenement.setTitle("Ajouter un evenement");
		frmAjouterUnEvenement.setBounds(100, 100, 395, 523);
		frmAjouterUnEvenement.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmAjouterUnEvenement.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 379, 529);
		frmAjouterUnEvenement.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 51, 255));
		panel_1.setBounds(0, 0, 379, 65);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblAppInSciences = new JLabel("App In Sciences ");
		lblAppInSciences.setForeground(Color.WHITE);
		lblAppInSciences.setFont(new Font("Bookman Old Style", Font.BOLD, 14));
		lblAppInSciences.setBounds(10, 11, 135, 26);
		panel_1.add(lblAppInSciences);
		
		textField_hf = new JTextField();
		textField_hf.setBounds(179, 264, 147, 20);
		panel.add(textField_hf);
		textField_hf.setColumns(10);
		
		txtDebutFin = new JTextField();
		txtDebutFin.setBounds(180, 184, 146, 20);
		panel.add(txtDebutFin);
		txtDebutFin.setColumns(10);
		
		JComboBox comboBox_type = new JComboBox();
		comboBox_type.setModel(new DefaultComboBoxModel(new String[] {"Type", "Workshop", "Meeting", "Comp\u00E9tition", ""}));
		comboBox_type.setBounds(180, 144, 146, 20);
		panel.add(comboBox_type);
		
		JLabel lblTypeDevenement = new JLabel("Type  :");
		lblTypeDevenement.setBounds(64, 147, 71, 14);
		panel.add(lblTypeDevenement);
		
		JLabel lblDate = new JLabel("Date debut-fin  :");
		lblDate.setBounds(64, 187, 106, 14);
		panel.add(lblDate);
		
		JLabel lblEndroit = new JLabel("Endroit :");
		lblEndroit.setBounds(64, 309, 46, 14);
		panel.add(lblEndroit);
		
		textField_nom = new JTextField();
		textField_nom.setBounds(180, 102, 147, 20);
		panel.add(textField_nom);
		textField_nom.setColumns(10);
		
		JLabel lblNom = new JLabel("Nom  :");
		lblNom.setBounds(64, 105, 46, 14);
		panel.add(lblNom);
		
		JLabel lblHeureDebut = new JLabel("Heure_fin:");
		lblHeureDebut.setBounds(64, 267, 86, 14);
		panel.add(lblHeureDebut);
		
		textField_endroit = new JTextField();
		textField_endroit.setColumns(10);
		textField_endroit.setBounds(180, 306, 147, 20);
		panel.add(textField_endroit);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(180, 347, 147, 20);
		panel.add(textField);
		
		JLabel lblCotFinal = new JLabel("Co\u00FBt final :");
		lblCotFinal.setBounds(64, 388, 71, 14);
		panel.add(lblCotFinal);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(180, 385, 147, 20);
		panel.add(textField_1);
		
		textField_hd = new JTextField();
		textField_hd.setText("<dynamic>");
		textField_hd.setColumns(10);
		textField_hd.setBounds(179, 225, 147, 20);
		panel.add(textField_hd);
		int row=ShowEventsNoyau.table1.getSelectedRow();
		String nom=ShowEventsNoyau.table1.getModel().getValueAt(row, 0).toString();
		
		String datedebutfin=ShowEventsNoyau.table1.getModel().getValueAt(row, 1).toString();
		String hd=ShowEventsNoyau.table1.getModel().getValueAt(row, 2).toString();
		String hf=ShowEventsNoyau.table1.getModel().getValueAt(row, 3).toString();

		String type=ShowEventsNoyau.table1.getModel().getValueAt(row, 4).toString();
		String endroit=ShowEventsNoyau.table1.getModel().getValueAt(row, 5).toString();
		String couti=ShowEventsNoyau.table1.getModel().getValueAt(row, 6).toString();
		String coutf=ShowEventsNoyau.table1.getModel().getValueAt(row, 7).toString();
		
		
	
	textField_nom.setText(nom);
	txtDebutFin.setText(datedebutfin);
	textField_hd.setText(hd);
	textField_hf.setText(hf);

	textField_endroit.setText(endroit);

	comboBox_type.setModel(new DefaultComboBoxModel(new String[] {type, "Workshop", "Meeting", "Comp\u00E9tition", ""}));
    textField.setText(couti);
    
    textField_1.setText(coutf); 
		
		JButton button_modifierEvenmt = new JButton("");
		button_modifierEvenmt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (!textField_hf.getText().isEmpty()&&
						!textField_nom.getText().isEmpty()&&
						!textField_hd.getText().isEmpty()&&

						!txtDebutFin.getText().isEmpty()&&
						!textField_endroit.getText().isEmpty()&&
						!String.valueOf(comboBox_type.getSelectedItem()).equals("Type")&&
						!textField.getText().isEmpty()
						) {
							
					Evenement event = new Evenement(textField_nom.getText(),txtDebutFin.getText(), textField_hd.getText(),textField_hf.getText(),textField_endroit.getText(),String.valueOf(comboBox_type.getSelectedItem()),Double.valueOf(textField.getText()) ,Double.valueOf(textField_1.getText()));
							 try {

								 EvenementDao.updateEvent(event,nom);
						            JOptionPane.showMessageDialog(null, "Modified succesfully!");
						            frmAjouterUnEvenement.dispose();
					            } catch (Exception ex) {
					                ex.printStackTrace();
					            }	
					}
					
				
			}
		});
		button_modifierEvenmt.setIcon(new ImageIcon(ModifierEvent.class.getResource("/project/images/icons8_update_left_rotation_24px.png")));
		button_modifierEvenmt.setBounds(221, 430, 71, 47);
		panel.add(button_modifierEvenmt);
		
		JLabel lblCo = new JLabel("Co\u00FBt initial :");
		lblCo.setBounds(64, 350, 71, 14);
		panel.add(lblCo);
		
		JLabel lblHeuredebut = new JLabel("Heure_debut:");
		lblHeuredebut.setBounds(64, 228, 86, 14);
		panel.add(lblHeuredebut);
		
		
		
		
	}
}
