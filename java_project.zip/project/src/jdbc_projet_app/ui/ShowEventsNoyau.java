package jdbc_projet_app.ui;
import jdbc_projet_app.dao.EvenementDao;

import jdbc_peojet_app.core.Evenement;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import jdbc_peojet_app.core.Evenement;
import jdbc_projet_app.dao.EvenementDao;
import javax.swing.JScrollBar;
/**
 * cette classe permet � l'admin d'acc�der � la liste des �v�nements , et de supprimer , modifier ou ajouter un �v�nement  � travers la Gui
 *@author Ait m'hand oubrahim yasmina 
 *@author Aji soukaina
 *
 */
public class ShowEventsNoyau {

	JFrame frmEvenement;
	private JTextField textField;
	static JTable table1;
	private String numero = null ;
	private Evenement event = null;
	/**
	 * Launch the application.
	 */
	public static void Events() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ShowEventsNoyau window = new ShowEventsNoyau();
					window.frmEvenement.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Creation de l'application.
	 */
	public ShowEventsNoyau() {
		initialize();
	}

	/**
	 * Initialisation du contenu de la frame.
	 */
	private void initialize() {
		frmEvenement = new JFrame();
		frmEvenement.setTitle("Evenement");
		frmEvenement.setBounds(100, 100, 552, 536);
		frmEvenement.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		Object[][] data1 = new Object[][]{};

        try {

            data1 = new String[EvenementDao.getAllEvents().size()][9];

            for (int i = 0; i < EvenementDao.getAllEvents().size(); i++)
                data1[i] = EvenementDao.getAllEvents().get(i).toArray();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		frmEvenement.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 170, 520, 231);
		scrollPane.setToolTipText("");
		panel.add(scrollPane);
		
		JButton button_chercher = new JButton("");
		button_chercher.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
               String nom = textField.getText();
		        

		        List<Evenement> result = null;
		        int size = 0;

		        try {
		            result = EvenementDao.searchEvent(nom);
		            size = result.size();

		        } catch (Exception ex) {
		            ex.printStackTrace();
		        }

		        String[][] data1 = new String[size][10];

		        for (int i = 0; i < size; i++)
		            data1[i] = result.get(i).toArray();

		        JTable table1 = new JTable(data1, new String[] { "Nom",  "Date_debut_fin","heure_debut","Heure_fin",  "Type","Endroit", "cout_initial","cout_final"
				});

		        table1.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
		            @Override
		            public void valueChanged(ListSelectionEvent event) {

		            	
		                numero = table1.getValueAt(table1.getSelectedRow(), 0).toString();
		                

		            }
		        });
		        scrollPane.setViewportView(table1);
		        table1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		    }

				
			
		});
		button_chercher.setBounds(337, 96, 80, 42);
		button_chercher.setIcon(new ImageIcon(ShowEventsNoyau.class.getResource("/project/images/icons8_google_web_search_24px.png")));
		panel.add(button_chercher);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 0, 552, 68);
		panel_1.setLayout(null);
		panel_1.setBackground(Color.BLUE);
		panel.add(panel_1);
		
		JLabel lblAppInSciences = new JLabel("App In Sciences");
		lblAppInSciences.setForeground(Color.WHITE);
		lblAppInSciences.setFont(new Font("Bookman Old Style", Font.BOLD, 14));
		lblAppInSciences.setBounds(10, 11, 139, 26);
		panel_1.add(lblAppInSciences);
		
		JButton button_quitter = new JButton("");
		button_quitter.setBounds(422, 434, 87, 42);
		button_quitter.setIcon(new ImageIcon(ShowEventsNoyau.class.getResource("/project/images/icons8_close_window_26px.png")));
		button_quitter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmEvenement.dispose();
				
			}
		});
		panel.add(button_quitter);
		
		textField = new JTextField();
		textField.setBounds(176, 110, 119, 20);
		textField.setColumns(10);
		panel.add(textField);
		
		JLabel lblNomDvnement = new JLabel("Nom d'\u00E9v\u00E9nement :");
		lblNomDvnement.setBounds(45, 113, 121, 14);
		panel.add(lblNomDvnement);
		table1 = new JTable(data1, new String[] { "Nom",  "Date_debut_fin","heure_debut","Heure_fin",  "Type","Endroit", "cout_initial","cout_final"
		});
		JButton button_add = new JButton("");
		button_add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddEvents event= new AddEvents();
				event.Event();
			}
		});
		button_add.setBounds(209, 434, 59, 42);
		button_add.setIcon(new ImageIcon(ShowEventsNoyau.class.getResource("/project/images/icons8_add_24px.png")));
		panel.add(button_add);
		
		JButton button_delete = new JButton("");
		button_delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int row=table1.getSelectedRow();
					if (row>=0) {
					String cellnom=table1.getModel().getValueAt(row, 0).toString();
			EvenementDao.deleteEvent(cellnom);
            JOptionPane.showMessageDialog(null, "Delited succesfully!");
					}
					else 
			            JOptionPane.showMessageDialog(null, "Vous devez selectioner un evenement! ");

        } catch (Exception ex) {
            ex.printStackTrace();
        }
			}
		});
		button_delete.setBounds(25, 434, 59, 42);
		button_delete.setIcon(new ImageIcon(ShowEventsNoyau.class.getResource("/project/images/icons8_delete_sign_26px.png")));
		panel.add(button_delete);
		
		JButton button_update = new JButton("");
		button_update.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ModifierEvent m= new ModifierEvent();
				m.Event();
			}
		});
		
		button_update.setBounds(117, 434, 59, 42);
		button_update.setIcon(new ImageIcon(ShowEventsNoyau.class.getResource("/project/images/icons8_update_left_rotation_24px.png")));
		panel.add(button_update);
		
		
		
		
		/*table1.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Nom", "Heure_debut", "Heure_fin", "Date_debut", "Date_fin", "Endroit", "Type", "cout_intital", "cout_final"
			}
		));*/
		
			
		
		
		table1.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		scrollPane.setViewportView(table1);
	}

}
