package jdbc_projet_app.ui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JTextField;

import jdbc_peojet_app.core.Reunion;
import jdbc_projet_app.dao.ReunionDao;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
/**
 * cette classe permet de modifier une reunion � travers la Gui
 *@author Ait m'hand oubrahim yasmina 
 *@author Aji soukaina
 *
 */
public class ModifierReunion {

	private JFrame frmAjouterUneReunion;
	private JTextField textField_hrdebut;
	private JTextField textField_theme;
	private JTextField textField_hrfin;
	private JTextField textField_date;
	private JTextField textField_endroit;

	/**
	 * Launch the application.
	 */
	public static void Mod() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ModifierReunion window = new ModifierReunion();
					window.frmAjouterUneReunion.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Creation de l'application.
	 */
	public ModifierReunion() {
		initialize();
	}

	/**
	 * Initialisation de la frame.
	 */
	private void initialize() {
		frmAjouterUneReunion = new JFrame();
		frmAjouterUneReunion.setTitle("Ajouter une reunion");
		frmAjouterUneReunion.setBounds(100, 100, 384, 453);
		frmAjouterUneReunion.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmAjouterUneReunion.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 368, 414);
		frmAjouterUneReunion.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 51, 255));
		panel_1.setBounds(0, 0, 379, 65);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblAppInSciences = new JLabel("App In Sciences");
		lblAppInSciences.setForeground(Color.WHITE);
		lblAppInSciences.setFont(new Font("Bookman Old Style", Font.BOLD, 14));
		lblAppInSciences.setBounds(10, 11, 122, 26);
		panel_1.add(lblAppInSciences);
		
		textField_hrdebut = new JTextField();
		textField_hrdebut.setBounds(180, 139, 147, 20);
		panel.add(textField_hrdebut);
		textField_hrdebut.setColumns(10);
		
		JLabel lblEndroit = new JLabel("Type :");
		lblEndroit.setBounds(64, 220, 60, 14);
		panel.add(lblEndroit);
		
		textField_theme = new JTextField();
		textField_theme.setBounds(180, 102, 147, 20);
		panel.add(textField_theme);
		textField_theme.setColumns(10);
		
		JLabel lblNom = new JLabel("Theme  :");
		lblNom.setBounds(64, 105, 71, 14);
		panel.add(lblNom);
		
		JLabel lblHeureDebut = new JLabel("Heure debut  :");
		lblHeureDebut.setBounds(64, 145, 83, 14);
		panel.add(lblHeureDebut);
		
		JLabel lblHeureFin = new JLabel("Heure fin  :");
		lblHeureFin.setBounds(64, 184, 83, 14);
		panel.add(lblHeureFin);
		
		textField_hrfin = new JTextField();
		textField_hrfin.setColumns(10);
		textField_hrfin.setBounds(180, 181, 147, 20);
		panel.add(textField_hrfin);
		
		textField_date = new JTextField();
		textField_date.setColumns(10);
		textField_date.setBounds(180, 257, 147, 20);
		panel.add(textField_date);
		
		textField_endroit = new JTextField();
		textField_endroit.setColumns(10);
		textField_endroit.setBounds(180, 299, 147, 20);
		panel.add(textField_endroit);
		
		JComboBox comboBox_type = new JComboBox();
		comboBox_type.setModel(new DefaultComboBoxModel(new String[] {"Type " , "Ferm\u00E9", "Ouvete"}));
		comboBox_type.setBounds(180, 217, 147, 20);
		panel.add(comboBox_type);
		
		JLabel label_1 = new JLabel("Endroit :");
		label_1.setBounds(64, 302, 71, 14);
		panel.add(label_1);
		
		int row=ShowReunionNoy.table3.getSelectedRow();
		
		String theme=ShowReunionNoy.table3.getModel().getValueAt(row, 0).toString();
		String hd=ShowReunionNoy.table3.getModel().getValueAt(row, 1).toString();
		String hf=ShowReunionNoy.table3.getModel().getValueAt(row, 2).toString();

		String date=ShowReunionNoy.table3.getModel().getValueAt(row, 3).toString();
		
		String endroit=ShowReunionNoy.table3.getModel().getValueAt(row, 4).toString();
		String type=ShowReunionNoy.table3.getModel().getValueAt(row, 5).toString();
		
		
	
	textField_theme.setText(theme);
	textField_date.setText(date);
	textField_hrdebut.setText(hd);
	textField_hrfin.setText(hf);

	textField_endroit.setText(endroit);

	comboBox_type.setModel(new DefaultComboBoxModel(new String[] {type, "Workshop", "Meeting", "Comp\u00E9tition", ""}));
    
    
		JButton button_ajouterReunion = new JButton("");
		button_ajouterReunion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (!textField_endroit.getText().isEmpty()&&
						!textField_date.getText().isEmpty()&&
						!textField_hrfin.getText().isEmpty()&&
						!textField_hrdebut.getText().isEmpty()&&
					!textField_theme.getText().isEmpty()&&
						!String.valueOf(comboBox_type.getSelectedItem()).equals("Type")
)					
						 {
							
					Reunion reunion = new Reunion(textField_theme.getText(),textField_hrdebut.getText(), textField_hrfin.getText(),	String.valueOf(comboBox_type.getSelectedItem()),textField_date.getText(),textField_endroit.getText() );
							 try {

								 ReunionDao.updateReunion(reunion,theme);
						            JOptionPane.showMessageDialog(null, "Modified succesfully!");
						            frmAjouterUneReunion.dispose();
					            } catch (Exception ex) {
					                ex.printStackTrace();
					            }	
					}
					

			}
		});
		button_ajouterReunion.setIcon(new ImageIcon(ModifierReunion.class.getResource("/project/images/icons8_update_left_rotation_24px.png")));
		button_ajouterReunion.setBounds(231, 344, 60, 47);
		panel.add(button_ajouterReunion);
		
		
		
		JLabel lblEndroit_1 = new JLabel("Date :");
		lblEndroit_1.setBounds(64, 260, 71, 14);
		panel.add(lblEndroit_1);
		
		
	}

}
