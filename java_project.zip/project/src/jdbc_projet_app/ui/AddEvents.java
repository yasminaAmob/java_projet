package jdbc_projet_app.ui;
import jdbc_peojet_app.core.Evenement;
import jdbc_projet_app.dao.EvenementDao;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JTextField;



import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
/**
 * cette classe permet de ajouter une �v�nement � la base de donn�e  � travers la GUI 
 *@author Ait m'hand oubrahim yasmina 
 *@author Aji soukaina
 *
 */
public class AddEvents {

	private JFrame frmAjouterUnEvenement;
	private JTextField textField_endrout;
	private JTextField textField_datedeb;
	private JTextField textField_nom;
	private JTextField textField_hf;
	private JTextField textField_coutin;
	private JTextField textField_coutf;
	private JTextField textField_hd;

	/**
	 * Launch the application.
	 */
	public static void Event() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddEvents window = new AddEvents();
					window.frmAjouterUnEvenement.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Creation de  l'application.
	 */
	public AddEvents() {
		initialize();
	}

	/**
	 * Initialiser le contenu de la frame.
	 */
	private void initialize() {
		frmAjouterUnEvenement = new JFrame();
		frmAjouterUnEvenement.setTitle("Ajouter un evenement");
		frmAjouterUnEvenement.setBounds(100, 100, 395, 530);
		frmAjouterUnEvenement.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmAjouterUnEvenement.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 379, 529);
		frmAjouterUnEvenement.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 51, 255));
		panel_1.setBounds(0, 0, 379, 65);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblAppInSciences = new JLabel("App In Sciences ");
		lblAppInSciences.setForeground(Color.WHITE);
		lblAppInSciences.setFont(new Font("Bookman Old Style", Font.BOLD, 14));
		lblAppInSciences.setBounds(10, 11, 135, 26);
		panel_1.add(lblAppInSciences);
		
		textField_endrout = new JTextField();
		textField_endrout.setBounds(180, 314, 147, 20);
		panel.add(textField_endrout);
		textField_endrout.setColumns(10);
		
		textField_datedeb = new JTextField();
		textField_datedeb.setBounds(180, 184, 146, 20);
		panel.add(textField_datedeb);
		textField_datedeb.setColumns(10);
		
		JComboBox comboBox_type = new JComboBox();
		comboBox_type.setModel(new DefaultComboBoxModel(new String[] {"Type", "Workshop", "Meeting", "Comp\u00E9tition", ""}));
		comboBox_type.setBounds(180, 144, 146, 20);
		panel.add(comboBox_type);
		
		JLabel lblTypeDevenement = new JLabel("Type  :");
		lblTypeDevenement.setBounds(64, 147, 71, 14);
		panel.add(lblTypeDevenement);
		
		JLabel lblDate = new JLabel("Date debut_fin  :");
		lblDate.setBounds(64, 187, 95, 14);
		panel.add(lblDate);
		
		JLabel lblEndroit = new JLabel("Endroit :");
		lblEndroit.setBounds(64, 317, 46, 14);
		panel.add(lblEndroit);
		
		textField_nom = new JTextField();
		textField_nom.setBounds(180, 102, 147, 20);
		panel.add(textField_nom);
		textField_nom.setColumns(10);
		
		JLabel lblNom = new JLabel("Nom  :");
		lblNom.setBounds(64, 105, 46, 14);
		panel.add(lblNom);
		
		JLabel lblDateFin = new JLabel("Heure_fin  :");
		lblDateFin.setBounds(64, 275, 71, 14);
		panel.add(lblDateFin);
		
		textField_hf = new JTextField();
		textField_hf.setColumns(10);
		textField_hf.setBounds(180, 272, 146, 20);
		panel.add(textField_hf);
		
		textField_coutin = new JTextField();
		textField_coutin.setColumns(10);
		textField_coutin.setBounds(180, 353, 147, 20);
		panel.add(textField_coutin);
		
		textField_hd = new JTextField();
		textField_hd.setColumns(10);
		textField_hd.setBounds(180, 228, 146, 20);
		panel.add(textField_hd);

		
		
		textField_coutf = new JTextField();
		textField_coutf.setColumns(10);
		textField_coutf.setBounds(180, 391, 147, 20);
		panel.add(textField_coutf);
		
		JButton button_ajouterEvenmt = new JButton("");
		button_ajouterEvenmt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (!textField_endrout.getText().isEmpty()&&
						!textField_nom.getText().isEmpty()&&
						!textField_datedeb.getText().isEmpty()&&
						!textField_coutf.getText().isEmpty()&&
					!textField_hf.getText().isEmpty()&&
					!textField_hd.getText().isEmpty()&&
						!String.valueOf(comboBox_type.getSelectedItem()).equals("Type")&&
						!textField_coutin.getText().isEmpty())
					
						 {
							
					Evenement event = new Evenement(textField_nom.getText(),textField_datedeb.getText(), textField_hd.getText(), textField_hf.getText(),textField_endrout.getText(),	String.valueOf(comboBox_type.getSelectedItem()),Integer.valueOf(textField_coutin.getText()),Integer.valueOf(textField_coutf.getText()) );
							 try {

								 EvenementDao.addEvent(event);
						            JOptionPane.showMessageDialog(null, "Added succesfully!");
						            frmAjouterUnEvenement.dispose();
					            } catch (Exception ex) {
					                ex.printStackTrace();
					            }	
					}
				else
		            JOptionPane.showMessageDialog(null, "Vous devez remplir tous les champs !");

				
			}
		});
		button_ajouterEvenmt.setIcon(new ImageIcon(AddEvents.class.getResource("/project/images/icons8_calendar_plus_30px_1.png")));
		button_ajouterEvenmt.setBounds(215, 430, 71, 47);
		panel.add(button_ajouterEvenmt);
		
		JLabel lblCo = new JLabel("Co\u00FBt initial :");
		lblCo.setBounds(64, 356, 71, 14);
		panel.add(lblCo);
		
		JLabel lblCotFinal = new JLabel("Co\u00FBt final :");
		lblCotFinal.setBounds(64, 394, 71, 14);
		panel.add(lblCotFinal);
		
		JLabel lblHeuredebut = new JLabel("Heure_debut :");
		lblHeuredebut.setBounds(64, 231, 71, 14);
		panel.add(lblHeuredebut);
		
		
	}
}
