package jdbc_projet_app.ui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import java.awt.CardLayout;
import javax.swing.JTextField;
import javax.swing.JEditorPane;
import javax.swing.JScrollPane;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import com.jgoodies.forms.layout.FormSpecs;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.SystemColor;
import java.awt.Font;
import javax.swing.UIManager;
import javax.swing.JButton;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
/**
 * cette classe permet � l'admin d'accederau membres , reunions , �v�nements et gestion compta  � travers la Gui 
 *@author Ait m'hand oubrahim yasmina 
 *@author Aji soukaina
 *
 */
public class projectApp {

	private JFrame frmMenuPrincipal;
	private JPanel panel_1;
	private JPanel panel_membre;
	private JLabel lblNewLabel_1;
	private JLabel label;
	private JLabel lblUpOnScience;
	private JLabel lblEspaceAdherent;
	private JPanel panel_5;
	private JPanel panel_evenmt;
	private JLabel label_4;
	private JLabel lblEvenement;
	private JPanel panel_reunion;
	private JLabel label_1;
	private JLabel lblReunion;
	private JPanel Money;
	private JLabel label_2;
	private JLabel label_3;

	/**
	 * Launch the application.
	 */
	public static void noyau() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					projectApp window = new projectApp();
					window.frmMenuPrincipal.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Creation de l'application.
	 */
	public projectApp() {
		initialize();
	}

	/**
	 * Initialiser le contenu de la frame.
	 */
	private void initialize() {
		frmMenuPrincipal = new JFrame();
		frmMenuPrincipal.setTitle("Menu principal");
		frmMenuPrincipal.setBounds(100, 100, 632, 530);
		frmMenuPrincipal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		GroupLayout groupLayout = new GroupLayout(frmMenuPrincipal.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addComponent(panel, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 616, Short.MAX_VALUE)
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addComponent(panel, GroupLayout.DEFAULT_SIZE, 441, Short.MAX_VALUE)
		);
		panel.setLayout(null);
		
		panel_1 = new JPanel();
		panel_1.setBounds(0, 0, 646, 165);
		panel_1.setBackground(new Color(0, 51, 255));
		panel_1.setForeground(new Color(0, 206, 209));
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		panel_5 = new JPanel();
		panel_5.setBounds(46, 42, 521, 79);
		panel_1.add(panel_5);
		panel_5.setBackground(new Color(0, 102, 255));
		panel_5.setLayout(null);
		
		label = new JLabel("");
		label.setBounds(22, 18, 50, 50);
		panel_5.add(label);
		label.setIcon(new ImageIcon(projectApp.class.getResource("/project/images/icons8_physics_50px_2.png")));
		
		lblUpOnScience = new JLabel("App In Sciences");
		lblUpOnScience.setBounds(57, 0, 130, 29);
		panel_5.add(lblUpOnScience);
		lblUpOnScience.setBackground(new Color(255, 255, 255));
		lblUpOnScience.setForeground(new Color(255, 255, 255));
		lblUpOnScience.setFont(new Font("Arial", Font.BOLD, 14));
		
		panel_membre = new JPanel();
		panel_membre.setBounds(237, 230, 142, 114);
		panel_membre.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				setColor(panel_membre);
			}
			public void mouseExited(MouseEvent e) {
				resetColor(panel_membre);
			}

			private void setColor(JPanel panel) {
				// TODO Auto-generated method stub
				panel.setBackground(new Color(115, 163, 239));
			}
			private void resetColor(JPanel panel) {
				// TODO Auto-generated method stub
				panel.setBackground(new Color(240,240,240));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				crud c=new crud();
				c.membrecrud();
			}
		});
		panel.add(panel_membre);
		panel_membre.setBackground(SystemColor.menu);
		panel_membre.setLayout(null);
		
		lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setIcon(new ImageIcon(projectApp.class.getResource("/project/images/icons8_batch_assign_filled_50px.png")));
		lblNewLabel_1.setBounds(46, 11, 55, 55);
		panel_membre.add(lblNewLabel_1);
		
		lblEspaceAdherent = new JLabel("     Espace membre");
		lblEspaceAdherent.setForeground(new Color(0, 51, 255));
		lblEspaceAdherent.setFont(new Font("Arial", Font.BOLD, 13));
		lblEspaceAdherent.setBounds(0, 77, 129, 14);
		panel_membre.add(lblEspaceAdherent);
		
		panel_evenmt = new JPanel();
		panel_evenmt.setBounds(47, 230, 142, 114);
		
		panel_evenmt.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				setColor(panel_evenmt);
			}
			public void mouseExited(MouseEvent e) {
				resetColor(panel_evenmt);
			}

			private void setColor(JPanel panel) {
				// TODO Auto-generated method stub
				panel.setBackground(new Color(115, 163, 239));
			}
			private void resetColor(JPanel panel) {
				// TODO Auto-generated method stub
				panel.setBackground(new Color(240,240,240));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				ShowEventsNoyau event= new ShowEventsNoyau();
				event.Events();		
				}
		});
		
		
		panel_evenmt.setLayout(null);
		panel_evenmt.setBackground(SystemColor.menu);
		panel.add(panel_evenmt);
		
		label_4 = new JLabel("");
		label_4.setIcon(new ImageIcon(projectApp.class.getResource("/project/images/icons8_calendar_filled_50px.png")));
		label_4.setBounds(46, 12, 50, 55);
		panel_evenmt.add(label_4);
		
		lblEvenement = new JLabel("         Evenement");
		lblEvenement.setForeground(new Color(0, 51, 255));
		lblEvenement.setFont(new Font("Arial", Font.BOLD, 13));
		lblEvenement.setBounds(0, 78, 129, 14);
		panel_evenmt.add(lblEvenement);
		
		panel_reunion = new JPanel();
		panel_reunion.setBounds(427, 230, 142, 114);
		panel_reunion.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				setColor(panel_reunion);
			}
			public void mouseExited(MouseEvent e) {
				resetColor(panel_reunion);
			}

			private void setColor(JPanel panel) {
				// TODO Auto-generated method stub
				panel.setBackground(new Color(115, 163, 239));
			}
			private void resetColor(JPanel panel) {
				// TODO Auto-generated method stub
				panel.setBackground(new Color(240,240,240));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				ShowReunionNoy reun= new ShowReunionNoy();
				reun.ShowReunion();
			}
		});
		panel_reunion.setLayout(null);
		panel_reunion.setBackground(SystemColor.menu);
		panel.add(panel_reunion);
		
		label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon(projectApp.class.getResource("/project/images/icons8_meeting_room_filled_50px.png")));
		label_1.setBounds(45, 11, 54, 55);
		panel_reunion.add(label_1);
		
		lblReunion = new JLabel("           Reunion");
		lblReunion.setForeground(new Color(0, 51, 255));
		lblReunion.setFont(new Font("Arial", Font.BOLD, 13));
		lblReunion.setBounds(0, 77, 129, 14);
		panel_reunion.add(lblReunion);
		
		Money = new JPanel();
		Money.setBounds(237, 367, 142, 86);
		Money.addMouseListener(new MouseAdapter() {
			@Override
		public void mouseEntered(MouseEvent e) {
			setColor(Money);
		}
		public void mouseExited(MouseEvent e) {
			resetColor(Money);
		}

		private void setColor(JPanel panel) {
			// TODO Auto-generated method stub
			panel.setBackground(new Color(115, 163, 239));
			
		}
		private void resetColor(JPanel panel) {
			// TODO Auto-generated method stub
			panel.setBackground(new Color(240,240,240));
		}
		@Override
		public void mouseClicked(MouseEvent e) {
			MontantClub c=new MontantClub();
			c.Money();
		}
	});
		Money.setLayout(null);
		Money.setBackground(SystemColor.menu);
		panel.add(Money);
		
		label_2 = new JLabel("");
		label_2.setIcon(new ImageIcon(projectApp.class.getResource("/project/images/icons8_sell_property_52px.png")));
		label_2.setBounds(46, 12, 52, 49);
		Money.add(label_2);
		
		label_3 = new JLabel("");
		label_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(0);
			}
		});
		label_3.setIcon(new ImageIcon(projectApp.class.getResource("/project/images/icons8_exit_32px.png")));
		label_3.setBounds(570, 442, 36, 38);
		panel.add(label_3);
		frmMenuPrincipal.getContentPane().setLayout(groupLayout);
		
	}
}
