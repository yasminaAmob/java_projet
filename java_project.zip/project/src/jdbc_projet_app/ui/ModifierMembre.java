package jdbc_projet_app.ui;
import  jdbc_peojet_app.core.Membre;
import jdbc_projet_app.dao.MembreDao;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;


import jdbc_projet_app.dao.MembreDao;

import java.awt.Font;
/**
 * cette classe permet de modifier un membre � travers la Gui
 *@author Ait m'hand oubrahim yasmina 
 *@author Aji soukaina
 *
 */
public class ModifierMembre {

	private JFrame frmAjouterUnNouveau;
	protected JTextField textField_nom;
	protected JTextField textField_prenom;
	protected JTextField textField_dn;
	protected JTextField textField_tel;
	protected JTextField textField_adresse;
	protected JTextField textField_mdp;
	protected JTextField textField;
	

	/**
	 * Launch the application.
	 */
	public static void Update() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ModifierMembre window = new ModifierMembre();
					window.frmAjouterUnNouveau.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Creation de l'application.
	 */
	public ModifierMembre() {
		initialize();
	}

	/**
	 * Initialisation de la  frame.
	 */
	private void initialize() {
		frmAjouterUnNouveau = new JFrame();
		frmAjouterUnNouveau.setTitle("modifier les donn\u00E9es d'un membre");
		frmAjouterUnNouveau.setBounds(100, 100, 395, 638);
		frmAjouterUnNouveau.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmAjouterUnNouveau.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 379, 619);
		frmAjouterUnNouveau.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 51, 255));
		panel_1.setBounds(0, 0, 381, 52);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("App In Sciences ");
		lblNewLabel.setBounds(10, 11, 138, 18);
		lblNewLabel.setFont(new Font("Bookman Old Style", Font.BOLD, 14));
		lblNewLabel.setForeground(Color.WHITE);
		panel_1.add(lblNewLabel);
		
		textField_nom = new JTextField();
		textField_nom.setBounds(152, 90, 157, 20);
		panel.add(textField_nom);
		textField_nom.setColumns(10);
		
		textField_prenom = new JTextField();
		textField_prenom.setBounds(152, 129, 157, 20);
		panel.add(textField_prenom);
		textField_prenom.setColumns(10);
		
		textField_dn = new JTextField();
		textField_dn.setToolTipText("jj/mm/yyyy");
		textField_dn.setBounds(152, 171, 157, 20);
		panel.add(textField_dn);
		textField_dn.setColumns(10);
		
		textField_tel = new JTextField();
		textField_tel.setText(" ");
		textField_tel.setBounds(152, 248, 157, 20);
		panel.add(textField_tel);
		textField_tel.setColumns(10);
		
		JComboBox comboBox_filiere = new JComboBox();
		comboBox_filiere.setToolTipText("\r\n");
		comboBox_filiere.setModel(new DefaultComboBoxModel(new String[] {"Filiere ", "2ITE", "ISIC", "GI", "GEE", "Cycle Prepa"}));
		comboBox_filiere.setBounds(152, 366, 157, 20);
		panel.add(comboBox_filiere);
		
		JLabel lblNom = new JLabel("Nom :");
		lblNom.setBounds(33, 93, 46, 14);
		panel.add(lblNom);
		
		JLabel lblPrenom = new JLabel("Prenom :");
		lblPrenom.setBounds(33, 132, 61, 14);
		panel.add(lblPrenom);
		
		JLabel lblNaissance = new JLabel("Date de naissance :");
		lblNaissance.setBounds(33, 174, 119, 14);
		panel.add(lblNaissance);
		
		JLabel lblTalephone = new JLabel("Telephone :");
		lblTalephone.setBounds(33, 251, 75, 14);
		panel.add(lblTalephone);
		
		JLabel lblType = new JLabel("Filiere  :");
		lblType.setBounds(33, 369, 75, 14);
		panel.add(lblType);
		
		JLabel label = new JLabel("Type :");
		label.setBounds(33, 410, 75, 14);
		panel.add(label);
		
		JComboBox comboBox_type = new JComboBox();
		comboBox_type.setModel(new DefaultComboBoxModel(new String[] {"Type", "Noyau", "Adherent"}));
		comboBox_type.setToolTipText("\r\n");
		comboBox_type.setBounds(152, 407, 157, 20);
		panel.add(comboBox_type);
		
		
		
		JLabel lblAdresse = new JLabel("Adresse :");
		lblAdresse.setBounds(33, 212, 75, 14);
		panel.add(lblAdresse);
		
		textField_adresse = new JTextField();
		textField_adresse.setText(" ");
		textField_adresse.setColumns(10);
		textField_adresse.setBounds(152, 209, 157, 20);
		panel.add(textField_adresse);
		
		JLabel lblGenre = new JLabel("Genre :");
		lblGenre.setBounds(33, 332, 75, 14);
		panel.add(lblGenre);
		
		JComboBox comboBox_genre = new JComboBox();
		comboBox_genre.setModel(new DefaultComboBoxModel(new String[] {"Genre", "Femme", "Homme"}));
		comboBox_genre.setToolTipText("\r\n");
		comboBox_genre.setBounds(152, 329, 157, 20);
		panel.add(comboBox_genre);
		
		JLabel lblNationalit = new JLabel("Nationalit\u00E9 :");
		lblNationalit.setBounds(33, 451, 75, 14);
		panel.add(lblNationalit);
		
		JComboBox comboBox_nat = new JComboBox();
		comboBox_nat.setModel(new DefaultComboBoxModel(new String[] {"Nationalite ", "Maroc ", "Autre"}));
		comboBox_nat.setToolTipText("\r\n");
		comboBox_nat.setBounds(152, 448, 157, 20);
		panel.add(comboBox_nat);
		
		JLabel lblMotDePasse = new JLabel("Mot de passe  :");
		lblMotDePasse.setBounds(33, 487, 75, 14);
		panel.add(lblMotDePasse);
		
		textField_mdp = new JTextField();
		textField_mdp.setText(" ");
		textField_mdp.setColumns(10);
		textField_mdp.setBounds(152, 484, 157, 20);
		panel.add(textField_mdp);
		
		JLabel lblEmail = new JLabel("Email :");
		lblEmail.setBounds(33, 291, 75, 14);
		panel.add(lblEmail);
		
		textField = new JTextField();
		textField.setText(" ");
		textField.setColumns(10);
		textField.setBounds(152, 288, 157, 20);
		panel.add(textField);
		 
		int row=crud.table.getSelectedRow();
	
		String nom=crud.table.getModel().getValueAt(row, 0).toString();
		String prenom=crud.table.getModel().getValueAt(row, 1).toString();
		String date=crud.table.getModel().getValueAt(row, 2).toString();
		String adresse=crud.table.getModel().getValueAt(row, 3).toString();
		String tel=crud.table.getModel().getValueAt(row, 4).toString();
		String email=crud.table.getModel().getValueAt(row, 5).toString();
		String genre=crud.table.getModel().getValueAt(row, 6).toString();
		String filiere=crud.table.getModel().getValueAt(row, 7).toString();
		
		String type=crud.table.getModel().getValueAt(row, 8).toString();
		
		String nationalite=crud.table.getModel().getValueAt(row, 9).toString();
		String mdp=crud.table.getModel().getValueAt(row, 10).toString();

		
	
	textField_nom.setText(nom);
    textField_prenom.setText(prenom);
	textField_dn.setText(date);
	textField_tel.setText(tel);
	textField_adresse.setText(adresse);
	textField_mdp.setText(mdp);
    textField.setText(email);
    comboBox_genre.setModel(new DefaultComboBoxModel(new String[] {genre, "Femme", "Homme"}));
	comboBox_nat.setModel(new DefaultComboBoxModel(new String[] {nationalite , "Maroc ", "Autre"}));
	comboBox_type.setModel(new DefaultComboBoxModel(new String[] {type, "Noyau", "Adherent"}));
	comboBox_filiere.setModel(new DefaultComboBoxModel(new String[] {filiere , "2ITE", "ISIC", "GI", "GEE", "Cycle Prepa"}));

    
    
		JButton ajoutermembre = new JButton("");
		ajoutermembre.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if (!textField_nom.getText().isEmpty()&&
				!textField_prenom.getText().isEmpty()&&
				!textField_dn.getText().isEmpty()&&
				!textField_tel.getText().isEmpty()&&
			!textField_mdp.getText().isEmpty()&&
				!String.valueOf(comboBox_filiere.getSelectedItem()).equals("Filiere")&&
				!String.valueOf(comboBox_type.getSelectedItem()).equals("Type")&&
				!textField_adresse.getText().isEmpty()&&
				!String.valueOf(comboBox_genre.getSelectedItem()).equals("Genre")&&
				!String.valueOf(comboBox_nat.getSelectedItem()).equals("Nationalite")&&
				!textField.getText().isEmpty()) {
					
					Membre membre = new Membre(textField_nom.getText(),textField_prenom.getText(), textField_dn.getText(), textField_adresse.getText(),Integer.valueOf(textField_tel.getText().trim()),textField.getText(),String.valueOf(comboBox_genre.getSelectedItem()) ,String.valueOf(comboBox_filiere.getSelectedItem()),String.valueOf(comboBox_type.getSelectedItem()) ,
							String.valueOf(comboBox_nat.getSelectedItem()), textField_mdp.getText());
					 try {

						 MembreDao.updateMembre(membre,email);
				            JOptionPane.showMessageDialog(null, "Modified succesfully!");
				            frmAjouterUnNouveau.dispose();
			            } catch (Exception ex) {
			                ex.printStackTrace();
			            }	
			}
			}
		});
		ajoutermembre.setIcon(new ImageIcon(ModifierMembre.class.getResource("/project/images/icons8_update_left_rotation_24px.png")));
		ajoutermembre.setBounds(194, 531, 69, 52);
		panel.add(ajoutermembre);
		
	}
}
