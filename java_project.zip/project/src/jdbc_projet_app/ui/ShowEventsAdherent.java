package jdbc_projet_app.ui;
import jdbc_projet_app.dao.EvenementDao;
import jdbc_peojet_app.core.Evenement;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 * cette classe permet de afficher tous les �v�nement � un simple adherent  � travers la Gui
 *@author Ait m'hand oubrahim yasmina 
 *@author Aji soukaina
 *
 */


public class ShowEventsAdherent {

	private JFrame frmEvenement;
	private JTextField textField_nomev;
	private JTable table;
	private String numero = null ;
	private Evenement event = null;

	/**
	 * Launch the application.
	 */
	public static void EventA() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ShowEventsAdherent window = new ShowEventsAdherent();
					window.frmEvenement.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Creation de l'application.
	 */
	public ShowEventsAdherent() {
		initialize();
		}
	
	

	/**
	 * Initialisation du contenu de  la frame.
	 */
	private void initialize() {
		frmEvenement = new JFrame();
		frmEvenement.setTitle("Evenement");
		frmEvenement.setBounds(100, 100, 552, 525);
		frmEvenement.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		frmEvenement.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 170, 520, 246);
		scrollPane.setToolTipText("");
		panel.add(scrollPane);
		
		Object[][] data = new Object[][]{};

        try {

            data = new String[EvenementDao.getAllEvents().size()][4];

            for (int i = 0; i < EvenementDao.getAllEvents().size(); i++)
                data[i] = EvenementDao.getAllEvents().get(i).toArray();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
		
		
		JButton button_chercher = new JButton("");
		button_chercher.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nom = textField_nomev.getText();
		        

		        List<Evenement> result = null;
		        int size = 0;

		        try {
		            result = EvenementDao.searchEvent(nom);
		            size = result.size();

		        } catch (Exception ex) {
		            ex.printStackTrace();
		        }

		        String[][] data = new String[size][11];

		        for (int i = 0; i < size; i++)
		            data[i] = result.get(i).toArray();

		        JTable table = new JTable(data, new String[] { "Nom",  "Date_debut_fin","heure_debut","Heure_fin",  "Type","Endroit", "cout_initial","cout_final"
				});

		        table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
		            @Override
		            public void valueChanged(ListSelectionEvent event) {

		                numero = table.getValueAt(table.getSelectedRow(), 0).toString();
		                

		            }
		        });
		        scrollPane.setViewportView(table);
		        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		    }

			}
		);  

		            
		   
		
		
		JButton button_quitter = new JButton("");
		button_quitter.setBounds(422, 434, 87, 42);
		button_quitter.setIcon(new ImageIcon(ShowEventsAdherent.class.getResource("/project/images/icons8_close_window_26px.png")));
		button_quitter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmEvenement.dispose();
								
			}
		});
		panel.add(button_quitter);
		
		textField_nomev = new JTextField();
		textField_nomev.setBounds(155, 118, 140, 20);
		textField_nomev.setColumns(10);
		panel.add(textField_nomev);
		
		JLabel lblNomDvnement = new JLabel("Nom d'\u00E9v\u00E9nement :");
		lblNomDvnement.setBounds(45, 121, 121, 14);
		panel.add(lblNomDvnement);
		
		
		
		table = new JTable(data,new String[] { "Nom",  "Date_debut_fin","heure_debut","Heure_fin",  "Type","Endroit", "cout_initial","cout_final"
		});
		/*table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null},
			},
			new String[] {
				"Nom", "Heure_debut", "Heure_fin", "Date_debut", "Date_fin", "Endroit", "Type", "cout_intital", "cout_final"
			}
		));*/
		scrollPane.setViewportView(table);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		
		
		JLabel lblTableauDesvnements = new JLabel("Tableau des \u00E9v\u00E9nements");
		lblTableauDesvnements.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblTableauDesvnements.setBounds(188, 79, 179, 14);
		panel.add(lblTableauDesvnements);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 51, 255));
		panel_1.setBounds(0, 0, 536, 62);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel label = new JLabel("App In Sciences");
		label.setForeground(Color.WHITE);
		label.setFont(new Font("Bookman Old Style", Font.BOLD, 14));
		label.setBounds(10, 11, 139, 26);
		panel_1.add(label);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
                  String nom = textField_nomev.getText();
		        

		        List<Evenement> result = null;
		        int size = 0;

		        try {
		            result = EvenementDao.searchEvent(nom);
		            size = result.size();

		        } catch (Exception ex) {
		            ex.printStackTrace();
		        }

		        String[][] data = new String[size][10];

		        for (int i = 0; i < size; i++)
		            data[i] = result.get(i).toArray();

		        JTable table = new JTable(data, new String[] { "Nom",  "Date_debut_fin","heure_debut","Heure_fin",  "Type","Endroit", "cout_initial","cout_final"
				});

		        table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
		            @Override
		            public void valueChanged(ListSelectionEvent event) {

		            	
		                numero = table.getValueAt(table.getSelectedRow(), 0).toString();
		                

		            }
		        });
		        scrollPane.setViewportView(table);
		        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			}
		});
		btnNewButton.setIcon(new ImageIcon(ShowEventsAdherent.class.getResource("/project/images/icons8_google_web_search_24px.png")));
		btnNewButton.setBounds(353, 104, 57, 42);
		panel.add(btnNewButton);
	}
		}
