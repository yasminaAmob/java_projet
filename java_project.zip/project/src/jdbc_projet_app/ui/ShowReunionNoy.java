package jdbc_projet_app.ui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.ImageIcon;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import jdbc_projet_app.dao.EvenementDao;
import jdbc_projet_app.dao.	ReunionDao;
import jdbc_peojet_app.core.Reunion;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
/**
 * cette classe permet � l'admin d'acc�der � la liste des reunions , de modifier , ajouter ou supprimer une reunion  � travers la Gui
 *@author Ait m'hand oubrahim yasmina 
 *@author Aji soukaina
 *
 */
public class ShowReunionNoy {

	private JFrame frmReunion;
	static JTable table3;

	/**
	 * Launch the application.
	 */
	public static void ShowReunion() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ShowReunionNoy window = new ShowReunionNoy();
					window.frmReunion.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Creation de l'application.
	 */
	public ShowReunionNoy() {
		initialize();
	}

	/**
	 * Initialisation du contenu de la frame.
	 */
	private void initialize() {
		frmReunion = new JFrame();
		frmReunion.setTitle("Reunion");
		frmReunion.setBounds(100, 100, 547, 435);
		frmReunion.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmReunion.getContentPane().setLayout(null);
		
		Object[][] data1 = new Object[][]{};

        try {

            data1 = new String[ReunionDao.getAllReunions().size()][9];

            for (int i = 0; i < ReunionDao.getAllReunions().size(); i++)
                data1[i] = ReunionDao.getAllReunions().get(i).toArray();

        } catch (Exception ex) {
            ex.printStackTrace();
        }

		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 536, 486);
		frmReunion.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 0, 552, 68);
		panel_1.setLayout(null);
		panel_1.setBackground(Color.BLUE);
		panel.add(panel_1);
		
		JLabel lblAppInSciences = new JLabel("App In Sciences");
		lblAppInSciences.setForeground(Color.WHITE);
		lblAppInSciences.setFont(new Font("Bookman Old Style", Font.BOLD, 14));
		lblAppInSciences.setBounds(10, 11, 148, 26);
		panel_1.add(lblAppInSciences);
		
		JButton button_quitter = new JButton("");
		button_quitter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmReunion.dispose();
				
			}
		});
		button_quitter.setBounds(419, 340, 87, 42);
		button_quitter.setIcon(new ImageIcon(ShowReunionNoy.class.getResource("/project/images/icons8_close_window_26px.png")));
		panel.add(button_quitter);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 123, 510, 186);
		scrollPane.setToolTipText("");
		panel.add(scrollPane);
		
		table3 = new JTable(data1 , new String[] {
				"Theme",  "Heure_debut", "Heure_fin","Date", "Endroit", "Type"
			});
		/*table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
				{null, null, null, null, null, null},
			},
			new String[] {
				"Theme", "Date", "Heure_debut", "Heure_fin", "Endroit", "Type"
			}
		));*/
		scrollPane.setViewportView(table3);
		JButton button_delete = new JButton("");
		button_delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					int row=table3.getSelectedRow();
					if(row>=0) {
					String theme=table3.getModel().getValueAt(row, 0).toString();
			ReunionDao.deleteReunion(theme);
            JOptionPane.showMessageDialog(null, "Delited succesfully!");
					}
					else 
			            JOptionPane.showMessageDialog(null, "Vous devez selectioner un element! ");

        } catch (Exception ex) {
            ex.printStackTrace();
        }
				  }		});
		button_delete.setBounds(14, 340, 54, 42);
		button_delete.setIcon(new ImageIcon(ShowReunionNoy.class.getResource("/project/images/icons8_delete_sign_26px.png")));
		panel.add(button_delete);
		
		JButton button_update = new JButton("");
		button_update.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ModifierReunion modif=new ModifierReunion();
				modif.Mod();
				
			}
		});
		button_update.setBounds(78, 340, 54, 42);
		button_update.setIcon(new ImageIcon(ShowReunionNoy.class.getResource("/project/images/icons8_update_left_rotation_24px.png")));
		panel.add(button_update);
		
		JButton button_add = new JButton("");
		button_add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddReunion reunion= new AddReunion();
				reunion.Reunion();
			}
		});
		button_add.setBounds(142, 340, 54, 42);
		button_add.setIcon(new ImageIcon(ShowReunionNoy.class.getResource("/project/images/icons8_add_24px.png")));
		panel.add(button_add);
		
		JLabel lblTableauDesvnement = new JLabel("Tableau des R\u00E9unions ");
		lblTableauDesvnement.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblTableauDesvnement.setBounds(186, 89, 161, 14);
		panel.add(lblTableauDesvnement);
	}

}
