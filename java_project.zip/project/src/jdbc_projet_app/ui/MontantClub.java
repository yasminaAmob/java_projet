package jdbc_projet_app.ui;
import jdbc_projet_app.dao.EvenementDao;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
/**
 * cette classe permet de recuperer le montant total du club � travers la Gui 
 *@author Ait m'hand oubrahim yasmina 
 *@author Aji soukaina
 *
 */
public class MontantClub {

	private JFrame frame;
	private JTextField textField_montat_total;
	private JTextField textField_couts;
	private JTextField textField_reste;
    int total=0 ;
	/**
	 * Launch the application.
	 */
	public static void Money() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MontantClub window = new MontantClub();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Creation de l'application.
	 */
	public MontantClub() {
		try {
			initialize();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Initialisation de la frame.
	 
	 */
	private void initialize() throws Exception {
		frame = new JFrame();
		frame.setBounds(100, 100, 366, 255);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 350, 216);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 0, 374, 53);
		panel_1.setBackground(new Color(0, 51, 255));
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel label = new JLabel("App In Sciences");
		label.setForeground(Color.WHITE);
		label.setFont(new Font("Bookman Old Style", Font.BOLD, 14));
		label.setBounds(10, 11, 139, 26);
		panel_1.add(label);
		
		textField_montat_total = new JTextField();
		textField_montat_total.setBounds(159, 82, 108, 20);
		panel.add(textField_montat_total);
		textField_montat_total.setColumns(10);
		
		JLabel lblMontantTotal = new JLabel("Montant Total du club :");
		lblMontantTotal.setBounds(10, 85, 139, 14);
		panel.add(lblMontantTotal);
		
		textField_couts = new JTextField();
		textField_couts.setBounds(159, 113, 108, 20);
		panel.add(textField_couts);
		textField_couts.setColumns(10);
		
		textField_reste = new JTextField();
		textField_reste.setColumns(10);
		textField_reste.setBounds(104, 173, 108, 20);
		panel.add(textField_reste);
		
		textField_couts.setText(EvenementDao.SommeCoutinit());
		
		JLabel lblTotalDesCouts = new JLabel("Total des co\u00FBts perdus  :");
		lblTotalDesCouts.setBounds(10, 116, 139, 14);
		panel.add(lblTotalDesCouts);
		
		JLabel lblLeResteDu = new JLabel("Le reste du montant  :");
		lblLeResteDu.setBounds(58, 148, 123, 14);
		panel.add(lblLeResteDu);
		
		JButton btnNewButton = new JButton("calculer");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				
				
				String Chaine1, Chaine2, Chaine3;
				try {
					
					
					
					
					
					if (!textField_montat_total.getText().isEmpty()) {
						Chaine1=textField_couts.getText();
						Chaine2=textField_montat_total.getText();
						int total = Integer.parseInt(Chaine1)+Integer.parseInt(Chaine2);
						
						
						int reste = total-Integer.parseInt(EvenementDao.SommeCoutfin());
						Integer rr = new Integer(reste);
						Chaine3 = rr.toString();

						textField_reste.setText(Chaine3);

						}
					else 
			            JOptionPane.showMessageDialog(null, "vous devez saisir votre montant");

				} catch (NumberFormatException e1) {
					
					e1.printStackTrace();
				} catch (Exception e1) {
					
					e1.printStackTrace();
				}
				
				
			}
		});
		btnNewButton.setBounds(251, 172, 89, 23);
		panel.add(btnNewButton);
		
		
	}
}
