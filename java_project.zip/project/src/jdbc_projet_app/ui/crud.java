package jdbc_projet_app.ui;

import jdbc_peojet_app.core.Membre;
import jdbc_projet_app.dao.MembreDao;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;



import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.util.List;
import java.awt.event.ActionEvent;
/**
 * cette classe  permet � l'admin d'ajouter , supprimer , modifier , consulter ou chercher un membre , �v�nement ou reunion 
 * et aussi pour  la gestion de la  comptabilit� � travers la GUI 
 * @author Ait m'hand oubrahim yasmina 
 *@author Aji soukaina
 *
 *
 */
public class crud {

	JFrame frmMembre;
	static JTable table;
	private JTextField nom_membre;
	private JTextField prenom_membre;
	private String numero = null ;
	private Membre membre = null;
	/**
	 * Launch the application.
	 */
	public static void membrecrud() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					crud window = new crud();
					window.frmMembre.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Creation de l'application.
	 */
	public crud() {
		initialize();
	}

	/**
	 * Initialiser le contenu de la frame.
	 */
	private void initialize() {
		frmMembre = new JFrame();
		frmMembre.setTitle("Membre");
		frmMembre.setBounds(100, 100, 552, 526);
		frmMembre.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmMembre.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 536, 487);
		frmMembre.getContentPane().add(panel);
		panel.setLayout(null);
		
		
		
		Object[][] data = new Object[][]{};

        try {

            data = new String[MembreDao.getAllMembres().size()][6];

            for (int i = 0; i < MembreDao.getAllMembres().size(); i++)
                data[i] = MembreDao.getAllMembres().get(i).toArray();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 178, 520, 231);
		scrollPane.setToolTipText("");
		panel.add(scrollPane);
		
		JButton button_chercher = new JButton("");
		button_chercher.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nom = nom_membre.getText();
		        String prenom = prenom_membre.getText();

		        List<Membre> result = null;
		        int size = 0;

		        try {
		            result = MembreDao.searchMembre(nom, prenom);
		            size = result.size();

		        } catch (Exception ex) {
		            ex.printStackTrace();
		        }

		        String[][] data = new String[size][11];

		        for (int i = 0; i < size; i++)
		            data[i] = result.get(i).toArray();

		        JTable table = new JTable(data, new String[] { "nom", "prenom", "naissance", "Adresse", "Telephone", "Email", "Genre","Filiere", "Type", "nationalite",  "mdp"
		        });

		        table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
		            @Override
		            public void valueChanged(ListSelectionEvent event) {

		                numero = table.getValueAt(table.getSelectedRow(), 0).toString();
		                

		            }
		        });
		        scrollPane.setViewportView(table);
		        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		    }

			}
		);
		button_chercher.setBounds(342, 92, 66, 50);
		button_chercher.setIcon(new ImageIcon(crud.class.getResource("/project/images/icons8_google_web_search_24px.png")));
		panel.add(button_chercher);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 0, 552, 68);
		panel_1.setBackground(Color.BLUE);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("App In Sciences ");
		lblNewLabel.setBounds(10, 11, 159, 26);
		lblNewLabel.setFont(new Font("Bookman Old Style", Font.BOLD, 14));
		lblNewLabel.setForeground(Color.WHITE);
		panel_1.add(lblNewLabel);
		
		
		
		table = new JTable(data,new String[] { "nom", "prenom", "naissance", "Adresse", "Telephone", "Email", "Genre","Filiere", "Type", "nationalite",  "mdp"
	
			});
		/*table_1.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"nom", "prenom", "naissance", "Adresse", "Telephone", "Email", "Type", "Genre", "nationalite", "Filiere", "mdp"
			}
		));*/
		//table.getColumnModel().getColumn(5).setPreferredWidth(146);
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		scrollPane.setViewportView(table);
		
		JButton button_quitter = new JButton("");
		button_quitter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frmMembre.dispose();
			}
		});
		button_quitter.setIcon(new ImageIcon(crud.class.getResource("/project/images/icons8_close_window_26px.png")));
		button_quitter.setBounds(435, 434, 73, 42);
		panel.add(button_quitter);
		
		nom_membre = new JTextField();
		nom_membre.setBounds(173, 92, 119, 20);
		panel.add(nom_membre);
		nom_membre.setColumns(10);
		
		JLabel lblNom = new JLabel("Nom :");
		lblNom.setBounds(86, 95, 46, 14);
		panel.add(lblNom);
		
		JLabel lblPrenom = new JLabel("Prenom :");
		lblPrenom.setBounds(86, 128, 77, 14);
		panel.add(lblPrenom);
		
		prenom_membre = new JTextField();
		prenom_membre.setBounds(173, 123, 119, 20);
		panel.add(prenom_membre);
		prenom_membre.setColumns(10);
		
		JButton button_ajouter = new JButton("");
		button_ajouter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddAdherent a= new AddAdherent();
				a.Add();
			}
		});
		button_ajouter.setIcon(new ImageIcon(crud.class.getResource("/project/images/icons8_add_24px.png")));
		button_ajouter.setBounds(209, 434, 59, 42);
		panel.add(button_ajouter);
		
		JButton button_delete = new JButton("");
		button_delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
	            
						try {
							
							int row=table.getSelectedRow();
							if(row>=0 ) {
							String cellnom=table.getModel().getValueAt(row, 0).toString();
							String cellprenom=table.getModel().getValueAt(row, 1).toString();
							
		            MembreDao.deleteMembreNom(cellnom,cellprenom);
		            JOptionPane.showMessageDialog(null, "Delited succesfully!");
		            
							}
							else 
					            JOptionPane.showMessageDialog(null, "Vous devez selectioner un membre! ");

		        } catch (Exception ex) {
		            ex.printStackTrace();
		        }
		        
		    
			}
		});
		button_delete.setIcon(new ImageIcon(crud.class.getResource("/project/images/icons8_delete_sign_26px.png")));
		button_delete.setBounds(25, 434, 59, 42);
		panel.add(button_delete);
		
		JButton button_update = new JButton("");
		button_update.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
					

					
				
				ModifierMembre a= new ModifierMembre();
				
				a.Update();
				
			}
			
		});
		button_update.setIcon(new ImageIcon(crud.class.getResource("/project/images/icons8_update_left_rotation_24px.png")));
		button_update.setBounds(117, 434, 59, 42);
		panel.add(button_update);
	}
}
