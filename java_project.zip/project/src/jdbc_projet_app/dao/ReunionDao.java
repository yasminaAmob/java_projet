package jdbc_projet_app.dao;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import jdbc_peojet_app.core.Reunion;
/**
 * la classe ReunionDao perme la connexion avec la base de donn�e et elle continet les m�thodes ajouter, supprimer , modifier et chercher une reunion
 * @author Ait m'hand oubrahim Yasmina
 * @author Aji soukaina
 *
 */
public class ReunionDao {
	private static Connection myConn;
/**
 * la connexion avex la base de donn�e 
 * @throws Exception exception
 */
    private ReunionDao() throws Exception {

        // get db properties
        Properties props = new Properties();
        props.load(new FileInputStream("env.properties"));

        String user = props.getProperty("user");
        String password = props.getProperty("password");
        String dburl = props.getProperty("dburl");

        // connect to database
        myConn = DriverManager.getConnection(dburl, user, password);

        System.out.println(" connection successful to: " + dburl);
    }
/**
 * suppression d'une reunion 
 * @param theme theme de la reunion 
 * @throws SQLException sql exception
 */
    public static void deleteReunion(String theme) throws SQLException {
        PreparedStatement myStmt = null;

        try {
            // prepare statement
            myStmt = getMyConn().prepareStatement("delete from Reunion where theme=?");

            // set param
            myStmt.setString(1, theme);
            
            // execute SQL
            myStmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
/**
 * modifier les parametres de la  reunion
 * @param reunion la reunion
 * @param theme theme de la reunion
 * @throws SQLException sql exception
 */
    public static void updateReunion(Reunion reunion, String theme) throws SQLException {
        PreparedStatement myStmt = null;

        try {
            // prepare statement
            myStmt = getMyConn().prepareStatement(
                    "update Reunion"
                            + " set  heure_debut=?, heure_fin=?, type=?, date=?, lieu=?"
                            + " where theme=?;");

            // set params
            //myStmt.setString(1, reunion.getTheme());
            myStmt.setString(1, reunion.getHeure_debut());
            myStmt.setString(2, reunion.getHeure_fin());
            myStmt.setString(3, reunion.getType());
            myStmt.setString(4, reunion.getDate());
            myStmt.setString(5, reunion.getLieu());
            myStmt.setString(6, theme);

            // execute SQL
            myStmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
/**
 * l'ajout d'une reunion dans la base de donn�e
 * @param reunion la reunion
 * @throws Exception exception
 */
    public static void addReunion(Reunion reunion) throws Exception {
        PreparedStatement myStmt = null;

        try {
            // prepare statement
            myStmt = getMyConn().prepareStatement("insert into Reunion"
            		 + " (theme, heure_debut, heure_fin, type, date, lieu)"
                    + " values (?, ?, ?, ?, ?, ?)");

            // set params
            myStmt.setString(1, reunion.getTheme());
            myStmt.setString(2, reunion.getHeure_debut());
            myStmt.setString(3, reunion.getHeure_fin());
            myStmt.setString(4, reunion.getType());
            myStmt.setString(5, reunion.getDate());
            myStmt.setString(6, reunion.getLieu());
            
            // execute SQL
            myStmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
/**
 * recuperation de la connexion avec la base de donn�e
 * @return la connexion
 * @throws Exception exception
 */
    public static Connection getMyConn() throws Exception {

        if (myConn != null)
            return myConn;

        new ReunionDao();

        return myConn;
    }

    public static List<Reunion> getAllReunions() throws Exception {
        List<Reunion> list = new ArrayList<Reunion>();

        Statement myStmt = null;
        ResultSet myRs = null;

        try {
            myStmt = getMyConn().createStatement();
            myRs = myStmt.executeQuery("select * from Reunion order by id_reunion");

            while (myRs.next()) {
            	Reunion tempReunion = convertRowToReunion(myRs);
                list.add(tempReunion);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
/**
 * la recherche d'une reunion dans la base de donn�e
 * @param theme theme de la reunion
 * @return reunion
 * @throws Exception exception
 */
   
    public static List<Reunion> searchReunion(String theme) throws Exception {

        List<Reunion> list = new ArrayList<Reunion>();

        PreparedStatement myStmt = null;
        ResultSet myRs = null;

        theme = '%' + theme + '%';

        try {

            if (!theme.isEmpty()) {
                myStmt = getMyConn().prepareStatement("select * from Reunion where theme like  ? ");
                myStmt.setString(1, theme);
            
            } else {
                return getAllReunions();
            }


            myRs = myStmt.executeQuery();

            while (myRs.next()) {
            	Reunion tempReunion = convertRowToReunion(myRs);
                list.add(tempReunion);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;

    }
/**
 * recuperation d'une reunion selon l'id
 * @param id_reunion id de la reunion
 * @return reunion
 * @throws Exception exception
 */
    public static Reunion getReunion(int id_reunion) throws Exception {

    	Reunion reunion = null;

        PreparedStatement myStmt = null;
        ResultSet myRs = null;
        try {
            myStmt = getMyConn().prepareStatement("select * from Reunion where id_reunion = ? ");
            myStmt.setInt(1, id_reunion);
            myRs = myStmt.executeQuery();

            while (myRs.next()) {
            	reunion= convertRowToReunion(myRs);
            }

            return reunion;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return reunion;

    }
/**
 * recuperation de toutes les reunions
 * @param myRs rs
 * @return reunions
 * @throws SQLException exception
 */
    private static Reunion convertRowToReunion(ResultSet myRs) throws SQLException {

        int id_reunion = myRs.getInt("id_reunion");
        String theme = myRs.getString("theme");
        String heure_debut = myRs.getString("heure_debut");
        String heure_fin = myRs.getString("heure_fin");
        String type = myRs.getString("type");
        String date = myRs.getString("date");
        String lieu = myRs.getString("lieu");
        
        Reunion tempReunion = new Reunion( theme, heure_debut, heure_fin, type, date, lieu);

        return tempReunion;
    }

/**
 * fermeture de la connexion avec la base de donn�e
 * @param myConn connection
 * @param myStmt statement
 * @param myRs rs
 * @throws SQLException sql exception
 */
    private static void close(Connection myConn, Statement myStmt, ResultSet myRs) throws SQLException {
    	

        try {
            if (myRs != null) {
                myRs.close();
            }

            if (myStmt != null) {

            }

            if (getMyConn() != null) {
                getMyConn().close();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
/**
 * fermeture de la connexion
 * @param myStmt   statement
 * @param myRs rs
 * @throws SQLException sql exception
 */
    private static void close(Statement myStmt, ResultSet myRs) throws SQLException {
        close(null, myStmt, myRs);
    }
/**
 * fermeture de la connexion
 * @param myStmt statement
 * @throws SQLException sql exception
 */
    private static void close(Statement myStmt) throws SQLException {
        close(null, myStmt, null);
    }



}
