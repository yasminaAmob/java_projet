package jdbc_projet_app.dao;

import jdbc_peojet_app.core.Evenement;
import jdbc_peojet_app.core.Membre;

import java.util.*;
import java.sql.*;
import java.io.*;


/**
 * la classe �v�nementDao permet la connexion avec la base de donn�e et elle contient les m�thodes ajouter , chercher  , supprimer et modifier un membre 
 * @author Ait m'hand oubarhm yasmina
 *@author Aji soukaina
 */
public class EvenementDao {
	
	private static Connection myConn;
    /**
     * la connexion avec la base de donn�e 
     * @throws Exception exception
     */
    private EvenementDao() throws Exception {

        // get db properties
        Properties props = new Properties();
        props.load(new FileInputStream("env.properties"));

        String user = props.getProperty("user");
        String password = props.getProperty("password");
        String dburl = props.getProperty("dburl");

        // connect to database
        myConn = DriverManager.getConnection(dburl, user, password);

        System.out.println("DB connection successful to: " + dburl);
    }
/**
 * la suppression d'un �v�nement
 * @param nomEvent nom de l'evenement
 * @throws SQLException sql exception
 */
    public static void deleteEvent(String nomEvent) throws SQLException {
        PreparedStatement myStmt = null;

        try {
            // prepare statement
            myStmt = getMyConn().prepareStatement("delete from Evenement where nom_event=?");

            // set param
            myStmt.setString(1, nomEvent);
            

            // execute SQL
            myStmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
/**
 * la modification de l'�v�nement
 * @param event  l'�v�nement
 * @param nom  nom de l'�v�nement
 * @throws SQLException sql exception
 */
    public static void updateEvent(Evenement event ,String nom) throws SQLException {
        PreparedStatement myStmt = null;

        try {
            // prepare statement
            myStmt = getMyConn().prepareStatement(
                    "update Evenement"
                            + " set date_debut_fin=?,  heure_debut=?,  heure_fin=? ,lieu=?, type=?, cout_initial=?, cout_final=?"
                            + " where nom_event=?");

            // set params
            //myStmt.setString(1, event.getNomEvent());
            myStmt.setString(1, event.getDateDebutfin());
            myStmt.setString(2, event.getHeureDebut());
            myStmt.setString(3, event.getHeureFin());

            myStmt.setString(4, event.getLieu());
            myStmt.setString(5, event.getType());
            myStmt.setDouble(6, event.getCoutInitial());
            myStmt.setDouble(7, event.getCoutFinal());
            myStmt.setString(8, nom);

            // execute SQL
            myStmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    /**
     * reperation du cout initial de tous les �v�nements
     * @return somme des couts
     * @throws Exception exception
     */
    public static String SommeCoutinit() throws Exception {
        PreparedStatement myStmt = null;
        String somme = null ;

        try {
            // prepare statement
            myStmt = getMyConn().prepareStatement("select sum(cout_initial) from evenement"
            		 );

            

            // execute SQL
            ResultSet sum=myStmt.executeQuery();
            sum.next();
            somme=sum.getString(1);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
     return somme;
    }
    /**
     * recuperation du cout final de l'�v�nement
     * @return la somme des couts finaux
     * @throws Exception exception
     */
    public static String SommeCoutfin() throws Exception {
        PreparedStatement myStmt = null;
        String somme=null ;

        try {
            // prepare statement
            myStmt = getMyConn().prepareStatement("select sum(cout_final) from evenement"
            		 );

            

            // execute SQL
            myStmt.executeQuery();
            ResultSet sum=myStmt.executeQuery();
            sum.next();
            somme=sum.getString(1);
           
        } catch (Exception e) {
            e.printStackTrace();
        }
     return somme;
    }
/**
 * l'ajout d'un �v�nement
 * @param event l'�v�nement
 * @throws Exception exception
 */
    public static void addEvent(Evenement event) throws Exception {
        PreparedStatement myStmt = null;

        try {
            // prepare statement
            myStmt = getMyConn().prepareStatement("insert into evenement"
            		 + " (nom_event, date_debut_fin, heure_debut, heure_fin ,lieu, type, cout_initial, cout_final)"
                    + " values (?, ?, ?, ?, ?, ?, ?,?);");

            // set params
            myStmt.setString(1, event.getNomEvent());
            myStmt.setString(2, event.getDateDebutfin());
            myStmt.setString(3, event.getHeureDebut());
            myStmt.setString(4, event.getHeureFin());

            myStmt.setString(5, event.getLieu());
            myStmt.setString(6, event.getType());
            myStmt.setDouble(7, event.getCoutInitial());
            myStmt.setDouble(8, event.getCoutFinal());

            // execute SQL
            myStmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
/**
 * recuperation de la connexion
 * @return connexion
 * @throws Exception exception
 */
    public static Connection getMyConn() throws Exception {

        if (myConn != null)
            return myConn;

        new EvenementDao();

        return myConn;
    }
    
/**
 * recuperation de tous les �v�nement
 * @return all events
 * @throws Exception exception
 */
    public static List<Evenement> getAllEvents() throws Exception {
        List<Evenement> list = new ArrayList<Evenement>();

        Statement myStmt = null;
        ResultSet myRs = null;

        try {
            myStmt = getMyConn().createStatement();
            myRs = myStmt.executeQuery("select * from evenement order by id_event");

            while (myRs.next()) {
                Evenement tempEvent = convertRowToEvent(myRs);
                list.add(tempEvent);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
/**
 * la recherche d'un �v�nement
 * @param nomEvent nom de l'�v�nement
 * @return �v�nements 
 * @throws Exception exception
 */
    public static List<Evenement> searchEvent(String nomEvent) throws Exception {

        List<Evenement> list = new ArrayList<Evenement>();

        PreparedStatement myStmt = null;
        ResultSet myRs = null;

        nomEvent = '%' + nomEvent + '%';

        try {

            if (!nomEvent.isEmpty()) {
                myStmt = getMyConn().prepareStatement("select * from evenement where nom_event like  ? ");
                myStmt.setString(1, nomEvent);
            
            } else {
                return getAllEvents();
            }


            myRs = myStmt.executeQuery();

            while (myRs.next()) {
                Evenement tempEvent = convertRowToEvent(myRs);
                list.add(tempEvent);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;

    }
/**
 * la recuperation de l'�v�nement
 * @param numEvent nom de l'�v�nement
 * @return �v�nements
 * @throws Exception exception
 */
    public static Evenement getEvent(int numEvent) throws Exception {

        Evenement event = null;

        PreparedStatement myStmt = null;
        ResultSet myRs = null;
        try {
            myStmt = getMyConn().prepareStatement("select * from evenement where id_event = ? ");
            myStmt.setInt(1, numEvent);
            myRs = myStmt.executeQuery();

            while (myRs.next()) {
                event= convertRowToEvent(myRs);
            }

            return event;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return event;

    }
/**
 * recuperation de l'�v�nement
 * @param myRs
 * @return �v�nement
 * @throws SQLException sql exception
 */
    private static Evenement convertRowToEvent(ResultSet myRs) throws SQLException {

        //int numEvent = myRs.getInt("id_event");
        String nomEvent = myRs.getString("nom_event");
        String dateDebutfin =myRs.getString("date_debut_fin");
        String hd =myRs.getString("heure_debut");
        String hf =myRs.getString("heure_fin");

        String lieu =myRs.getString("lieu");
        String type =myRs.getString("type");
        double cout_initial =myRs.getDouble("cout_initial");
        double cout_final =myRs.getDouble("cout_final");
        
        Evenement tempEvent = new Evenement( nomEvent, dateDebutfin, hd ,hf, lieu, type, cout_initial, cout_final);

        return tempEvent;
    }

/**
 * fermer la connexion avec la bes de donn�es
 * @param myConn connexion 
 * @param myStmt statement 
 * @param myRs rs
 * @throws SQLException sql exception
 */
    private static void close(Connection myConn, Statement myStmt, ResultSet myRs) throws SQLException {

        try {
            if (myRs != null) {
                myRs.close();
            }

            if (myStmt != null) {

            }

            if (getMyConn() != null) {
                getMyConn().close();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
/**
 * fermer la connexion
 * @param myStmt statement 
 * @param myRs rs
 * @throws SQLException  sql exception
 */
    private static void close(Statement myStmt, ResultSet myRs) throws SQLException {
        close(null, myStmt, myRs);
    }
/**
 * fermer la connexion
 * @param myStmt statement
 * @throws SQLException sql exception
 */
    private static void close(Statement myStmt) throws SQLException {
        close(null, myStmt, null);
    }


}
