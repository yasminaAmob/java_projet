package jdbc_projet_app.dao;

import jdbc_peojet_app.core.Membre;

import java.util.*;
import java.sql.*;
import java.io.*;
import java.math.BigDecimal;
import java.time.LocalDate;
/**
 * la classe membreDaopermet la connexion avec la base de donn�e et elle contient les methodes ajouter , chercher , supprimer et modifier un membre 
 * @author Ait m'hand oubarhm yasmina
 *@author Aji soukaina
 * 
 *
 */
public class MembreDao {

	    private static Connection myConn;
/**
 * la connexion avec la base de donn�e
 * @throws Exception exception
 */
	    private MembreDao() throws Exception {

	        // get db properties
	        Properties props = new Properties();
	        props.load(new FileInputStream("env.properties"));

	        String user = props.getProperty("user");
	        String password = props.getProperty("password");
	        String dburl = props.getProperty("dburl");

	        // connect to database
	        myConn = DriverManager.getConnection(dburl, user, password);

	        System.out.println("connection successful to: " + dburl);
	    }
/** suppression d'un membre de la base de donn�e 
 * 
 * @param nom nom du memebre
 * @param prenom prenom du membre
 * @throws SQLException sql exception
 */
	    public static void deleteMembreNom(String nom, String prenom) throws SQLException {
	        PreparedStatement myStmt = null;

	        try {
	            // prepare statement
	            myStmt = getMyConn().prepareStatement("delete from Membre where nom=? and prenom=?");

	            // set param
	            myStmt.setString(1, nom);
	            myStmt.setString(2, prenom);

	            // execute SQL
	            myStmt.executeUpdate();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }finally {
	        	try {
	        		myStmt.close();
	        	}catch(Exception ex) {
	        	}
	        }
	    }
	    /**
	     * recuperation de l'email du membre d'apres la base de donn�e
	     * @return email
	     * @throws Exception exception
	     */
	    public static String email() throws Exception {
	        PreparedStatement myStmt = null;
	        String email=null ;

	        try {
	            // prepare statement
	            myStmt = getMyConn().prepareStatement("select email from membre"
	            		 );

	            

	            // execute SQL
	            myStmt.executeQuery();
	            ResultSet sum=myStmt.executeQuery();
	            sum.next();
	            email=sum.getString(1);
	           
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	     return email;
	    }
	    /**
	     * recuperation du mot de passe du membre de la base de donn�e
	     * @return mot de passe 
	     * @throws Exception exception
	     */
	    public static String pwd() throws Exception {
	        PreparedStatement myStmt = null;
	        String pwd=null ;

	        try {
	            // prepare statement
	            myStmt = getMyConn().prepareStatement("select pwd from membre"
	            		 );

	            

	            // execute SQL
	            myStmt.executeQuery();
	            ResultSet sum=myStmt.executeQuery();
	            sum.next();
	            pwd=sum.getString(1);
	           
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	     return pwd;
	    }

/**
 * la modification d'un membre 
 * @param membre membre
 * @param email email du membre
 * @throws SQLException sql exception
 */
	    public static void updateMembre(Membre membre, 	String email) throws SQLException {
	        PreparedStatement myStmt = null;

	        try {
	            // prepare statement
	            myStmt = getMyConn().prepareStatement(
	                    "update membre"
	                            + " set prenom=? , nom=? ,date_naiss=?, adresse=?, tele=?, type=?, genre=?, nationalite=?, filiere=? , pwd=? "
	                            + " where email=? ");

	            // set params
	            myStmt.setString(1, membre.getNom());
	            myStmt.setString(2, membre.getPrenom());
	            myStmt.setString(3, membre.getDate_naiss());
	            myStmt.setString(4, membre.getAddress());
	            myStmt.setInt(5, membre.getTele());
	               
	            myStmt.setString(6, membre.getType_membre());
	            myStmt.setString(7, membre.getGenre()); 
	            myStmt.setString(8, membre.getNationalite());
	            myStmt.setString(9, membre.getFiliere());
	            myStmt.setString(10, membre.getMdp());
	            myStmt.setString(11, email);
	            

	            // execute SQL
	            myStmt.executeUpdate();

	        } catch (Exception e) {
	            e.printStackTrace();
	        }

	    }
/**
 * l'ajout d'un membre dans la base de donn�e 
 * @param membre un membre
 * @throws Exception exception
 */
	    public static void addMembre(Membre membre) throws Exception {
	        PreparedStatement myStmt = null;

	        try {
	            // prepare statement
	            myStmt = getMyConn().prepareStatement("insert into membre"
	            		+" (nom, prenom, date_naiss, adresse, tele, email, type, genre, nationalite, filiere,pwd)"
	                    + " values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);");

	            // set params
	            myStmt.setString(1, membre.getNom());
	            myStmt.setString(2, membre.getPrenom());
	            myStmt.setString(3, membre.getDate_naiss());
	            myStmt.setString(4, membre.getAddress());
	            myStmt.setInt(5, membre.getTele());
	            myStmt.setString(6, membre.getEmail());     
	            myStmt.setString(7, membre.getType_membre());
	            myStmt.setString(8, membre.getGenre()); 
	            myStmt.setString(9, membre.getNationalite());
	            myStmt.setString(10, membre.getFiliere());
	            myStmt.setString(11, membre.getMdp());

	            // execute SQL
	            myStmt.executeUpdate();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }

	    }
/**
 * recuperation de la connexion avec la base de donn�e 
 * @return la connexion
 * @throws Exception exception
 */
	    public static Connection getMyConn() throws Exception {

	        if (myConn != null)
	            return myConn;

	        new MembreDao();

	        return myConn;
	    }
/**
 * reperation de tous les membres 
 * @return  tous les membres
 * @throws Exception exception
 */
	    public static List<Membre> getAllMembres() throws Exception {
	        List<Membre> list = new ArrayList<Membre>();

	        Statement myStmt = null;
	        ResultSet myRs = null;

	        try {
	            myStmt = getMyConn().createStatement();
	            myRs = myStmt.executeQuery("select * from membre order by id_membre");

	            while (myRs.next()) {
	                Membre tempMembre = convertRowToMembre(myRs);
	                list.add(tempMembre);
	            }

	        } catch (Exception e) {
	            e.printStackTrace();
	        }

	        return list;
	    }
/**
 * la recherche d'un membre dans la base de donn�e
 * @param nom nom du membre
 * @param prenom prenom du membre
 * @return  membre
 * @throws Exception  exception
 */
	    public static List<Membre> searchMembre(String nom, String prenom) throws Exception {

	        List<Membre> list = new ArrayList<Membre>();

	        PreparedStatement myStmt = null;
	        ResultSet myRs = null;

	        nom = '%' + nom + '%';
	        prenom = '%' + prenom + '%';

	        try {

	            if (!nom.isEmpty() && !prenom.isEmpty()) {
	                myStmt = getMyConn().prepareStatement("select * from membre where nom like  ?  and prenom like  ?  ");
	                myStmt.setString(1, nom);
	                myStmt.setString(2, prenom);
	            } else if (nom.isEmpty()) {
	                myStmt = getMyConn().prepareStatement("select * from membre where prenom like   ?  ");
	                myStmt.setString(1, prenom);
	            } else if (prenom.isEmpty()) {
	                myStmt = getMyConn().prepareStatement("select * from membre where nom like  ?  ");
	                myStmt.setString(1, nom);
	            } else {
	                return getAllMembres();
	            }


	            myRs = myStmt.executeQuery();

	            while (myRs.next()) {
	                Membre tempLivre = convertRowToMembre(myRs);
	                list.add(tempLivre);
	            }

	        } catch (Exception e) {
	            e.printStackTrace();
	        }

	        return list;

	    }
/**
 * recuperation d'un membre selon son id 
 * @param id id du membre
 * @return membre 
 * @throws Exception exception
 */
	    public static Membre getMembre(int id) throws Exception {

	        Membre membre = null;

	        PreparedStatement myStmt = null;
	        ResultSet myRs = null;
	        try {
	            myStmt = getMyConn().prepareStatement("select * from membre where id = ? ");
	            myStmt.setInt(1, id);
	            myRs = myStmt.executeQuery();

	            while (myRs.next()) {
	                membre= convertRowToMembre(myRs);
	            }

	            return membre;

	        } catch (Exception e) {
	            e.printStackTrace();
	        }

	        return membre;

	    }
/**
 * 
 * @param myRs rs
 * @return membre
 * @throws SQLException sql exception
 */
	    private static Membre convertRowToMembre(ResultSet myRs) throws SQLException {

	        //int id = myRs.getInt("id_membre");
	        String nom = myRs.getString("nom");
	        String prenom = myRs.getString("prenom");
	        String date_naiss= myRs.getString("date_naiss");
	        String address= myRs.getString("adresse");
	        int tele= myRs.getInt("tele");
	        String genre= myRs.getString("genre");
	        String email= myRs.getString("email");     
	        String type_membre= myRs.getString("type");
	        String filiere= myRs.getString("filiere");
	        String nationalite= myRs.getString("nationalite");
	        String mdp=myRs.getString("pwd");

	        Membre tempMembre = new Membre( nom,  prenom, date_naiss , address, tele , email,genre , filiere, type_membre ,nationalite,  mdp);

	        return tempMembre;
	    }

/**
 * fermer la connexion
 * @param myConn connexion
 * @param myStmt statement
 * @param myRs rs
 * @throws SQLException sql exception
 */
	    private static void close(Connection myConn, Statement myStmt, ResultSet myRs) throws SQLException {

	        try {
	            if (myRs != null) {
	                myRs.close();
	            }

	            if (myStmt != null) {

	            }

	            if (getMyConn() != null) {
	                getMyConn().close();
	            }

	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
/**
 * fermeture de  la connexion
 * @param myStmt statement
 * @param myRs rs
 * @throws SQLException sql exception
 */
	    private static void close(Statement myStmt, ResultSet myRs) throws SQLException {
	        close(null, myStmt, myRs);
	    }
/**
 * fermeture de la connexion
 * @param myStmt statement
 * @throws SQLException sql exception
 */
	    private static void close(Statement myStmt) throws SQLException {
	        close(null, myStmt, null);
	    }
	}

